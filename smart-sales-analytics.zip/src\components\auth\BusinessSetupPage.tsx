import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Store, MapPin, Tag, Package, ShoppingCart, ArrowRight, CheckCircle2 } from 'lucide-react';

export const BusinessSetupPage: React.FC = () => {
  const { businessProfile, updateBusinessProfile, setCurrentPage } = useApp();

  const [businessName, setBusinessName] = useState(businessProfile.name || 'Urban Threads');
  const [category, setCategory] = useState(businessProfile.category || 'Clothing & Fashion');
  const [location, setLocation] = useState(businessProfile.location || 'Pune, Maharashtra');
  const [numberOfProducts, setNumberOfProducts] = useState(businessProfile.numberOfProducts || '11-50');
  const [salesChannel, setSalesChannel] = useState(businessProfile.salesChannel || 'Own Website & WhatsApp');

  const categories = [
    'Clothing & Fashion',
    'Cosmetics',
    'Jewellery',
    'Food',
    'Lifestyle',
    'Other',
  ];

  const salesChannels = [
    'IndiaMART',
    'Justdial',
    'Own Website',
    'Shopify',
    'WooCommerce',
    'Instagram/WhatsApp',
    'Excel/CSV',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateBusinessProfile({
      name: businessName,
      category,
      location,
      numberOfProducts,
      salesChannel,
    });
    // Next step in core user flow: Connect Existing Sales Source / Upload Data
    setCurrentPage('connect-data');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8 font-sans">
      <div className="sm:mx-auto sm:w-full sm:max-w-xl text-center">
        <div className="inline-flex items-center gap-2 mb-2">
          <span className="text-xs font-bold text-blue-700 uppercase tracking-wider bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            Step 2 of 3: Business Setup
          </span>
        </div>
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
          Tell Us About Your Business
        </h1>
        <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
          We customize your analytics benchmarks, category velocity formulas, and seasonal demand predictions based on these details.
        </p>
      </div>

      <div className="mt-6 sm:mx-auto sm:w-full sm:max-w-xl px-4 sm:px-0">
        <form onSubmit={handleSubmit} className="bg-white py-8 px-6 sm:px-10 shadow-xl border border-slate-200 rounded-2xl space-y-5">
          {/* Business Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <Store className="w-3.5 h-3.5 text-slate-500" />
              <span>Business Name</span>
            </label>
            <input
              type="text"
              required
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              placeholder="e.g. Urban Threads"
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600"
            />
          </div>

          {/* Business Category */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-slate-500" />
              <span>Business Category</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {categories.map((cat) => (
                <button
                  type="button"
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`py-2 px-3 text-xs font-medium rounded-lg border text-left transition-all ${
                    category === cat
                      ? 'bg-blue-50 text-blue-700 border-blue-400 font-semibold shadow-2xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Business Location */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-slate-500" />
              <span>Business Location / City</span>
            </label>
            <input
              type="text"
              required
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. Pune, Maharashtra"
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600"
            />
          </div>

          {/* Number of Products */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <Package className="w-3.5 h-3.5 text-slate-500" />
              <span>Number of Active Products (Catalog Size)</span>
            </label>
            <div className="grid grid-cols-4 gap-2">
              {['1-10', '11-50', '51-200', '200+'].map((range) => (
                <button
                  type="button"
                  key={range}
                  onClick={() => setNumberOfProducts(range)}
                  className={`py-2 px-3 text-xs font-medium rounded-lg border text-center transition-all ${
                    numberOfProducts === range
                      ? 'bg-blue-50 text-blue-700 border-blue-400 font-semibold shadow-2xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {range}
                </button>
              ))}
            </div>
          </div>

          {/* Primary Sales Channel */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <ShoppingCart className="w-3.5 h-3.5 text-slate-500" />
              <span>Primary Sales Channel</span>
            </label>
            <select
              value={salesChannel}
              onChange={(e) => setSalesChannel(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 bg-white"
            >
              {salesChannels.map((channel) => (
                <option key={channel} value={channel}>
                  {channel}
                </option>
              ))}
            </select>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-sm shadow-blue-500/20 transition-colors"
            >
              <span>Continue to Data Connection</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
