import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatINR, formatNumber, formatPercent } from '../../utils/formatters';
import { ProductMetric } from '../../types';
import {
  Package,
  ArrowUpRight,
  ArrowDownRight,
  Search,
  Filter,
  ArrowRight,
  Boxes,
  Sparkles,
  AlertTriangle,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';

export const ProductPerformancePage: React.FC = () => {
  const { productMetrics, openProductDetail } = useApp();
  const [activeTab, setActiveTab] = useState<'all' | 'top' | 'fast' | 'slow' | 'declining'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Filter products based on tab & search
  const filteredProducts = productMetrics.filter((p) => {
    const matchesSearch =
      p.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.productId.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (activeTab === 'top') {
      return p.revenue >= (productMetrics[2]?.revenue || 0);
    }
    if (activeTab === 'fast') {
      return p.growthRate >= 10 || p.velocity >= 2.0;
    }
    if (activeTab === 'slow') {
      return p.velocity < 1.0;
    }
    if (activeTab === 'declining') {
      return p.growthRate < 0;
    }
    return true;
  });

  const getStatusBadge = (status: ProductMetric['status']) => {
    switch (status) {
      case 'High Demand':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'High Risk':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      case 'Healthy':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Review':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Slow Moving':
        return 'bg-slate-100 text-slate-700 border-slate-200';
      default:
        return 'bg-slate-100 text-slate-600 border-slate-200';
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Product Performance
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Analyze sales velocity, catalog revenue contribution, and growth trends per SKU.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500 bg-white px-3 py-1.5 rounded-lg border border-slate-200 shadow-2xs">
            {productMetrics.length} Catalog Items Indexed
          </span>
        </div>
      </div>

      {/* Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200/90 shadow-2xs">
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 text-xs">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'all'
                ? 'bg-blue-600 text-white font-semibold shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            All Products
          </button>
          <button
            onClick={() => setActiveTab('top')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'top'
                ? 'bg-blue-600 text-white font-semibold shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Top Products
          </button>
          <button
            onClick={() => setActiveTab('fast')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'fast'
                ? 'bg-blue-600 text-white font-semibold shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Fast Moving
          </button>
          <button
            onClick={() => setActiveTab('slow')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'slow'
                ? 'bg-blue-600 text-white font-semibold shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Slow Moving
          </button>
          <button
            onClick={() => setActiveTab('declining')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'declining'
                ? 'bg-blue-600 text-white font-semibold shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Declining
          </button>
        </div>

        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          <input
            type="text"
            placeholder="Search product or category..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 w-full sm:w-64"
          />
        </div>
      </div>

      {/* Main Performance Table */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600">
              <tr>
                <th className="py-3 px-4">Product Name</th>
                <th className="py-3 px-3">Category</th>
                <th className="py-3 px-3 text-right">Units Sold</th>
                <th className="py-3 px-3 text-right">Revenue</th>
                <th className="py-3 px-3 text-right">Avg Price</th>
                <th className="py-3 px-3 text-right">Growth</th>
                <th className="py-3 px-3 text-right">Stock</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-xs text-slate-400">
                    No products found for this filter tab.
                  </td>
                </tr>
              ) : (
                filteredProducts.map((p) => {
                  const isPositive = p.growthRate >= 0;
                  const isStockAlert = p.daysRemaining !== null && p.daysRemaining <= 7;

                  return (
                    <tr
                      key={p.productId}
                      onClick={() => openProductDetail(p)}
                      className="hover:bg-blue-50/40 cursor-pointer transition-colors group"
                    >
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-700 font-bold text-xs shrink-0 group-hover:border-blue-300">
                            <Package className="w-4 h-4 text-slate-500 group-hover:text-blue-600" />
                          </div>
                          <div>
                            <span className="font-bold text-slate-900 block group-hover:text-blue-600 transition-colors">
                              {p.productName}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {p.productId}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-3 text-slate-600">
                        {p.category}
                      </td>

                      <td className="py-3.5 px-3 text-right font-medium text-slate-800">
                        {formatNumber(p.unitsSold)}
                      </td>

                      <td className="py-3.5 px-3 text-right font-bold text-slate-900">
                        {formatINR(p.revenue)}
                      </td>

                      <td className="py-3.5 px-3 text-right text-slate-600">
                        {formatINR(p.averagePrice)}
                      </td>

                      <td className="py-3.5 px-3 text-right font-semibold">
                        <span
                          className={`inline-flex items-center text-xs ${
                            isPositive ? 'text-emerald-600' : 'text-rose-600'
                          }`}
                        >
                          {isPositive ? (
                            <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />
                          ) : (
                            <ArrowDownRight className="w-3.5 h-3.5 mr-0.5" />
                          )}
                          {formatPercent(p.growthRate)}
                        </span>
                      </td>

                      <td className="py-3.5 px-3 text-right">
                        {p.currentStock !== null ? (
                          <div>
                            <span className={`font-semibold ${isStockAlert ? 'text-rose-600 font-bold' : 'text-slate-800'}`}>
                              {p.currentStock} units
                            </span>
                            <span className="text-[10px] text-slate-400 block">
                              (~{p.daysRemaining ?? 0} days left)
                            </span>
                          </div>
                        ) : (
                          <span className="text-slate-400 text-[11px]">N/A</span>
                        )}
                      </td>

                      <td className="py-3.5 px-3">
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${getStatusBadge(p.status)}`}>
                          {p.status}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            openProductDetail(p);
                          }}
                          className="px-2.5 py-1 text-xs font-semibold text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded transition-colors inline-flex items-center gap-1"
                        >
                          <span>View Details</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
