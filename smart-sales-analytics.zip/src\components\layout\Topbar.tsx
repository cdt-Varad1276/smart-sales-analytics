import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { NotificationsDropdown } from './NotificationsDropdown';
import {
  Calendar,
  Download,
  Upload,
  User,
  LogOut,
  Settings,
  ChevronDown,
  Sparkles,
  Store,
  Layers,
} from 'lucide-react';

export const Topbar: React.FC = () => {
  const {
    businessProfile,
    dateRange,
    setDateRange,
    openUploadModal,
    openExportReportModal,
    setCurrentPage,
    logout,
    resetToDemoData,
  } = useApp();

  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setIsProfileOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between sticky top-0 z-20">
      {/* Left: Business Context Pill */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-md bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-700 font-bold text-xs">
            {businessProfile.name.slice(0, 2).toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-slate-900 leading-tight">
                {businessProfile.name}
              </h2>
              {businessProfile.isDemoData && (
                <span className="text-[10px] font-medium bg-amber-50 text-amber-800 border border-amber-200 px-1.5 py-0.2 rounded-full inline-flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5 text-amber-600" />
                  Demo Mode
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 font-medium">
              {businessProfile.category} • {businessProfile.location}
            </p>
          </div>
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-3">
        {/* Date Range Selector */}
        <div className="flex items-center bg-slate-100/90 p-1 rounded-lg border border-slate-200/80 text-xs">
          <Calendar className="w-3.5 h-3.5 text-slate-500 ml-1.5 mr-1" />
          <button
            onClick={() => setDateRange('all')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all ${
              dateRange === 'all'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Time
          </button>
          <button
            onClick={() => setDateRange('30d')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all ${
              dateRange === '30d'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Last 30 Days
          </button>
          <button
            onClick={() => setDateRange('90d')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all ${
              dateRange === '90d'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Last 90 Days
          </button>
          <button
            onClick={() => setDateRange('year')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all ${
              dateRange === 'year'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            This Year
          </button>
        </div>

        {/* Upload Data Button */}
        <button
          onClick={openUploadModal}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium rounded-lg shadow-sm transition-colors shadow-blue-500/20"
        >
          <Upload className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Upload CSV</span>
        </button>

        {/* Export Report Button */}
        <button
          onClick={openExportReportModal}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 text-xs font-medium rounded-lg shadow-2xs transition-colors"
        >
          <Download className="w-3.5 h-3.5 text-slate-500" />
          <span className="hidden sm:inline">Export Report</span>
        </button>

        {/* Notifications Dropdown */}
        <NotificationsDropdown />

        {/* User Profile Menu */}
        <div className="relative" ref={profileRef}>
          <button
            onClick={() => setIsProfileOpen(!isProfileOpen)}
            className="flex items-center gap-2 pl-2 pr-1.5 py-1 rounded-lg hover:bg-slate-100 transition-colors focus:outline-none"
          >
            <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center border border-blue-200">
              <User className="w-3.5 h-3.5" />
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
          </button>

          {isProfileOpen && (
            <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
              <div className="px-4 py-2 border-b border-slate-100">
                <p className="text-xs font-semibold text-slate-900">{businessProfile.name}</p>
                <p className="text-[11px] text-slate-500 truncate">{businessProfile.email}</p>
              </div>

              <div className="py-1">
                <button
                  onClick={() => {
                    setCurrentPage('settings');
                    setIsProfileOpen(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 text-left transition-colors"
                >
                  <Settings className="w-3.5 h-3.5 text-slate-400" />
                  <span>Business Settings</span>
                </button>

                <button
                  onClick={() => {
                    setCurrentPage('data-sources');
                    setIsProfileOpen(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 text-left transition-colors"
                >
                  <Layers className="w-3.5 h-3.5 text-slate-400" />
                  <span>Connected Data Sources</span>
                </button>

                <button
                  onClick={() => {
                    resetToDemoData();
                    setIsProfileOpen(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 text-left transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>Reload Urban Threads Demo</span>
                </button>
              </div>

              <div className="border-t border-slate-100 pt-1">
                <button
                  onClick={() => {
                    setIsProfileOpen(false);
                    logout();
                  }}
                  className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-red-600 hover:bg-red-50 text-left transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Log out</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
