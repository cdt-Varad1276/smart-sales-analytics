import React, { useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { formatINR, formatNumber, formatPercent, formatDate } from '../../utils/formatters';
import { X, Printer, Download, FileSpreadsheet, ShieldCheck, TrendingUp } from 'lucide-react';

export const ExportReportModal: React.FC = () => {
  const {
    isExportReportModalOpen,
    closeExportReportModal,
    businessProfile,
    overviewMetrics,
    productMetrics,
    cityMetrics,
    recommendations,
    dashboardInsights,
    showToast,
  } = useApp();

  const printAreaRef = useRef<HTMLDivElement>(null);

  if (!isExportReportModalOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadCsvSummary = () => {
    const lines: string[] = [];
    lines.push(`SMARTSELL ANALYTICS - EXECUTIVE SUMMARY`);
    lines.push(`Business Name,${businessProfile.name}`);
    lines.push(`Category,${businessProfile.category}`);
    lines.push(`Location,${businessProfile.location}`);
    lines.push(`Generated Date,${new Date().toISOString().split('T')[0]}`);
    lines.push(``);
    lines.push(`KEY PERFORMANCE INDICATORS`);
    lines.push(`Total Revenue,${overviewMetrics.totalRevenue}`);
    lines.push(`Total Orders,${overviewMetrics.totalOrders}`);
    lines.push(`Average Order Value,${overviewMetrics.averageOrderValue}`);
    lines.push(`Total Units Sold,${overviewMetrics.totalUnitsSold}`);
    lines.push(`Repeat Customers Rate %,${overviewMetrics.repeatCustomerPercentage.toFixed(1)}%`);
    lines.push(``);
    lines.push(`TOP PRODUCTS PERFORMANCE`);
    lines.push(`Product Name,Category,Units Sold,Revenue,Avg Price,Growth %,Current Stock,Status`);

    productMetrics.forEach((p) => {
      lines.push(
        `"${p.productName}","${p.category}",${p.unitsSold},${p.revenue},${p.averagePrice},${p.growthRate.toFixed(1)}%,${p.currentStock ?? 'N/A'},"${p.status}"`
      );
    });

    lines.push(``);
    lines.push(`TOP CITIES`);
    lines.push(`City,State,Orders,Revenue,Share %`);
    cityMetrics.forEach((c) => {
      lines.push(`"${c.city}","${c.state}",${c.orderCount},${c.revenue},${c.percentageOfRevenue.toFixed(1)}%`);
    });

    const csvContent = lines.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${businessProfile.name.toLowerCase().replace(/\s+/g, '_')}_executive_report.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showToast('Executive CSV summary downloaded successfully!', 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header (Hidden during browser print) */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70 print:hidden">
          <div>
            <h3 className="text-base font-bold text-slate-900">Executive Business Intelligence Report</h3>
            <p className="text-xs text-slate-500">
              Download as spreadsheet or generate a clean printable executive brief
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadCsvSummary}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg border border-slate-200 transition-colors shadow-2xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>Download CSV</span>
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg transition-colors shadow-sm shadow-blue-500/20"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>

            <button
              onClick={closeExportReportModal}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 rounded-lg transition-colors ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Area */}
        <div ref={printAreaRef} className="p-8 overflow-y-auto space-y-6 flex-1 text-slate-900 bg-white">
          {/* Report Title & Metadata */}
          <div className="border-b border-slate-200 pb-5">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-xs">
                    SS
                  </div>
                  <span className="font-bold text-lg text-slate-900 tracking-tight">SMARTSELL ANALYTICS</span>
                </div>
                <h1 className="text-xl font-bold text-slate-900 mt-2">
                  Business Performance & Decision Support Report
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Prepared for: <span className="font-semibold text-slate-800">{businessProfile.name}</span> ({businessProfile.category})
                </p>
              </div>

              <div className="text-right text-xs text-slate-500">
                <p>Location: <span className="font-medium text-slate-700">{businessProfile.location}</span></p>
                <p>Report Date: <span className="font-medium text-slate-700">{new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</span></p>
                <p>Data Source: <span className="font-medium text-slate-700">{businessProfile.dataSourceName}</span></p>
              </div>
            </div>
          </div>

          {/* KPI Summary Grid */}
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
              1. Executive Performance Metrics
            </h2>
            <div className="grid grid-cols-4 gap-3">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-[11px] text-slate-500 font-medium block">Total Revenue</span>
                <span className="text-lg font-bold text-slate-900 block mt-0.5">{formatINR(overviewMetrics.totalRevenue)}</span>
                <span className="text-[10px] text-emerald-600 font-semibold">{formatPercent(overviewMetrics.revenueGrowth)} vs prior period</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-[11px] text-slate-500 font-medium block">Total Orders</span>
                <span className="text-lg font-bold text-slate-900 block mt-0.5">{formatNumber(overviewMetrics.totalOrders)}</span>
                <span className="text-[10px] text-emerald-600 font-semibold">{formatPercent(overviewMetrics.ordersGrowth)} vs prior period</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-[11px] text-slate-500 font-medium block">Average Order Value</span>
                <span className="text-lg font-bold text-slate-900 block mt-0.5">{formatINR(overviewMetrics.averageOrderValue)}</span>
                <span className="text-[10px] text-emerald-600 font-semibold">{formatPercent(overviewMetrics.aovGrowth)} vs prior period</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-[11px] text-slate-500 font-medium block">Repeat Customer Rate</span>
                <span className="text-lg font-bold text-slate-900 block mt-0.5">{overviewMetrics.repeatCustomerPercentage.toFixed(1)}%</span>
                <span className="text-[10px] text-slate-500">{overviewMetrics.repeatCustomersCount} returning buyers</span>
              </div>
            </div>
          </div>

          {/* Top Insights */}
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
              2. Key Diagnostic Findings
            </h2>
            <div className="space-y-2">
              {dashboardInsights.map((ins, i) => (
                <div key={i} className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">{ins.title}</span>
                    <span className="text-[10px] font-semibold bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded">
                      {ins.impactLevel} Priority
                    </span>
                  </div>
                  <p className="text-slate-600 mt-1">{ins.whyItMatters}</p>
                  <p className="text-blue-900 font-medium mt-1">Recommended Action: {ins.recommendedAction}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Product Performance Table */}
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
              3. Catalog Performance & Inventory Health
            </h2>
            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600">
                  <tr>
                    <th className="py-2.5 px-3">Product Name</th>
                    <th className="py-2.5 px-3">Category</th>
                    <th className="py-2.5 px-3 text-right">Units</th>
                    <th className="py-2.5 px-3 text-right">Revenue</th>
                    <th className="py-2.5 px-3 text-right">Growth</th>
                    <th className="py-2.5 px-3 text-right">Stock</th>
                    <th className="py-2.5 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {productMetrics.map((p, i) => (
                    <tr key={i}>
                      <td className="py-2 px-3 font-semibold text-slate-900">{p.productName}</td>
                      <td className="py-2 px-3 text-slate-500">{p.category}</td>
                      <td className="py-2 px-3 text-right font-medium">{formatNumber(p.unitsSold)}</td>
                      <td className="py-2 px-3 text-right font-semibold">{formatINR(p.revenue)}</td>
                      <td className="py-2 px-3 text-right font-medium text-emerald-600">{formatPercent(p.growthRate)}</td>
                      <td className="py-2 px-3 text-right">{p.currentStock !== null ? `${p.currentStock} units` : '—'}</td>
                      <td className="py-2 px-3">
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                          {p.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Grounded Recommendations */}
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
              4. Immediate Strategic Next Steps
            </h2>
            <div className="space-y-2.5">
              {recommendations.slice(0, 3).map((rec, i) => (
                <div key={i} className="p-3 bg-blue-50/40 rounded-lg border border-blue-200 text-xs">
                  <div className="font-bold text-slate-900">
                    #{rec.number}. {rec.title} ({rec.category})
                  </div>
                  <p className="text-slate-600 mt-0.5"><span className="font-semibold text-slate-800">Reason:</span> {rec.reason}</p>
                  <p className="text-slate-600"><span className="font-semibold text-slate-800">Action:</span> {rec.action}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Footer note */}
          <div className="pt-4 border-t border-slate-200 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Generated by SmartSell Analytics BI Engine</span>
            <span>Confidential Business Data</span>
          </div>
        </div>

        {/* Footer controls (hidden during print) */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between print:hidden">
          <span className="text-xs text-slate-500">
            Click 'Print / Save PDF' to output a client-ready document or presentation artifact.
          </span>
          <button
            onClick={closeExportReportModal}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold rounded-lg transition-colors"
          >
            Close Preview
          </button>
        </div>
      </div>
    </div>
  );
};
