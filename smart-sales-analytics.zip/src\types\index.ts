export interface Order {
  order_id: string;
  order_date: string; // ISO YYYY-MM-DD
  customer_id: string;
  customer_name: string;
  customer_email?: string;
  product_id: string;
  product_name: string;
  category: string;
  quantity: number;
  unit_price: number;
  total_amount: number;
  city: string;
  state: string;
  payment_status: 'Completed' | 'Pending' | 'COD' | 'Failed';
  sales_channel?: string;
  stock_available?: number; // optional in CSV
}

export interface BusinessProfile {
  name: string;
  category: string;
  location: string;
  numberOfProducts: string;
  salesChannel: string;
  email: string;
  currency: string;
  createdDate: string;
  dataSourceName: string;
  isDemoData: boolean;
}

export interface ProductMetric {
  productId: string;
  productName: string;
  category: string;
  unitsSold: number;
  revenue: number;
  averagePrice: number;
  growthRate: number; // percentage change vs prior comparable period
  currentStock: number | null; // null if stock column missing
  velocity: number; // units sold per day
  daysRemaining: number | null; // stock / velocity
  status: 'High Demand' | 'Healthy' | 'Review' | 'Slow Moving' | 'High Risk' | 'No Stock Data';
  orderCount: number;
  topCity: string;
}

export interface CustomerMetric {
  customerId: string;
  customerName: string;
  city: string;
  orderCount: number;
  totalSpent: number;
  averageOrderValue: number;
  firstOrderDate: string;
  lastOrderDate: string;
  segment: 'New' | 'Returning' | 'High Value' | 'Inactive';
}

export interface CityMetric {
  city: string;
  state: string;
  orderCount: number;
  revenue: number;
  customersCount: number;
  percentageOfRevenue: number;
  topProduct: string;
}

export interface CategoryMetric {
  category: string;
  revenue: number;
  unitsSold: number;
  percentage: number;
  productCount: number;
}

export interface ForecastItem {
  productId: string;
  productName: string;
  historicalDailyAvg: number;
  historicalMonthlyAvg: number;
  forecastDailyAvg: number;
  forecastPeriodDays: number;
  forecastUnits: number;
  projectedRevenue: number;
  trend: 'Increasing' | 'Stable' | 'Softening';
  trendPercentage: number;
  confidenceInterval: { min: number; max: number };
  stockoutRiskDate: string | null;
  businessImplication: string;
  recommendedAction: string;
  historicalSeries: { date: string; units: number }[];
  forecastSeries: { date: string; units: number; lower: number; upper: number }[];
}

export interface BusinessInsight {
  id: string;
  type: 'growth' | 'location' | 'inventory' | 'customer';
  title: string;
  summary: string;
  whyItMatters: string;
  recommendedAction: string;
  impactLevel: 'High' | 'Medium' | 'Low';
  targetPage?: string;
  targetProductId?: string;
}

export interface BusinessRecommendation {
  id: string;
  number: number;
  title: string;
  category: 'Inventory' | 'Sales & Pricing' | 'Marketing & Geography' | 'Customer Retention';
  reason: string;
  impact: string;
  action: string;
  suggestedActionType: 'view_product' | 'reorder' | 'view_location' | 'discount_campaign';
  targetProductId?: string;
  targetCity?: string;
  isDone?: boolean;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'inventory' | 'sales' | 'forecast' | 'system';
  timestamp: string;
  read: boolean;
  linkPage?: string;
}

export type PageView =
  | 'landing'
  | 'login'
  | 'register'
  | 'business-setup'
  | 'connect-data'
  | 'dashboard'
  | 'sales-analytics'
  | 'products'
  | 'customers'
  | 'inventory'
  | 'forecast'
  | 'recommendations'
  | 'data-sources'
  | 'settings';
