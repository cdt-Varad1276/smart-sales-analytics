import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, ExternalLink, ShieldCheck, CheckCircle2, Clock, Sparkles } from 'lucide-react';

export const IntegrationModal: React.FC = () => {
  const { selectedIntegration, closeIntegrationModal, startDemoMode, showToast } = useApp();

  if (!selectedIntegration) return null;

  const isDemo = selectedIntegration.status.toLowerCase().includes('demo');
  const isComingSoon = selectedIntegration.status.toLowerCase().includes('coming');

  const handleDemoSync = () => {
    startDemoMode();
    closeIntegrationModal();
    showToast(`Loaded sample sales data for ${selectedIntegration.name} showcase.`, 'success');
  };

  const handleNotifyMe = () => {
    closeIntegrationModal();
    showToast(`You are on the priority waitlist for ${selectedIntegration.name} automated sync!`, 'info');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-700 font-bold text-xs">
              {selectedIntegration.name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">{selectedIntegration.name} Integration</h3>
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full inline-block mt-0.5 ${
                isDemo
                  ? 'bg-amber-50 text-amber-800 border border-amber-200'
                  : 'bg-slate-100 text-slate-700 border border-slate-200'
              }`}>
                {selectedIntegration.status}
              </span>
            </div>
          </div>
          <button
            onClick={closeIntegrationModal}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <p className="text-xs text-slate-600 leading-relaxed">
            {selectedIntegration.description}
          </p>

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
            <span className="font-semibold text-slate-800 block">How SmartSell Connects:</span>
            <div className="space-y-1.5 text-slate-600 text-[11px]">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                <span>Reads buyer inquiries, confirmed orders, and invoice records.</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                <span>Maps products, unit prices, and delivery locations to your catalog.</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                <span>Computes customer purchase history and demand forecasting.</span>
              </div>
            </div>
          </div>

          <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-200 text-xs text-blue-900 flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div className="leading-snug">
              <span className="font-semibold">Transparency Note:</span> This is a prototype integration environment. Direct API keys are not collected. For live data today, use the Excel/CSV pipeline.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={closeIntegrationModal}
            className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
          >
            Close
          </button>

          {isDemo ? (
            <button
              onClick={handleDemoSync}
              className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors shadow-sm shadow-blue-500/20"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Test with Demo Data</span>
            </button>
          ) : (
            <button
              onClick={handleNotifyMe}
              className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-black text-white text-xs font-bold rounded-lg transition-colors shadow-sm"
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Join Integration Waitlist</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
