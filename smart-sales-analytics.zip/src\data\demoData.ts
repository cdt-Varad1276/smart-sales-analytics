import { BusinessProfile, Order } from '../types';

export const initialBusinessProfile: BusinessProfile = {
  name: 'Urban Threads',
  category: 'Clothing & Fashion',
  location: 'Pune, Maharashtra',
  numberOfProducts: '11-50',
  salesChannel: 'Own Website & WhatsApp',
  email: 'founder@urbanthreads.demo',
  currency: '₹',
  createdDate: '2026-01-15',
  dataSourceName: 'Urban Threads (Fictional Demo Dataset)',
  isDemoData: true,
};

// Catalog configuration matching exact requirements
export const CATALOG_PRODUCTS = [
  {
    id: 'PRD-KURTI-01',
    name: 'Cotton Kurti',
    category: 'Kurtis & Tunics',
    basePrice: 650,
    stock: 18,
    targetUnits: 430,
    growthBias: 0.28,
  },
  {
    id: 'PRD-DENIM-02',
    name: 'Denim Jacket',
    category: 'Outerwear',
    basePrice: 1250,
    stock: 46,
    targetUnits: 215,
    growthBias: 0.08,
  },
  {
    id: 'PRD-SAREE-03',
    name: 'Printed Saree',
    category: 'Sarees',
    basePrice: 890,
    stock: 9,
    targetUnits: 195,
    growthBias: -0.06,
  },
  {
    id: 'PRD-SHIRT-04',
    name: 'Casual Shirt',
    category: 'Casual Wear',
    basePrice: 580,
    stock: 65,
    targetUnits: 160,
    growthBias: 0.04,
  },
  {
    id: 'PRD-LINEN-05',
    name: 'Linen Top',
    category: 'Kurtis & Tunics',
    basePrice: 520,
    stock: 32,
    targetUnits: 110,
    growthBias: 0.12,
  },
  {
    id: 'PRD-ETHNIC-06',
    name: 'Ethnic Dress',
    category: 'Festive Wear',
    basePrice: 1150,
    stock: 24,
    targetUnits: 75,
    growthBias: 0.15,
  },
  {
    id: 'PRD-SCARF-07',
    name: 'Silk Scarf',
    category: 'Accessories',
    basePrice: 320,
    stock: 8,
    targetUnits: 40,
    growthBias: -0.02,
  },
  {
    id: 'PRD-DUPATTA-08',
    name: 'Chanderi Dupatta',
    category: 'Accessories',
    basePrice: 420,
    stock: 14,
    targetUnits: 23,
    growthBias: 0.05,
  },
];

const CITIES = [
  { city: 'Pune', state: 'Maharashtra', weight: 42 },
  { city: 'Mumbai', state: 'Maharashtra', weight: 26 },
  { city: 'Nashik', state: 'Maharashtra', weight: 11 },
  { city: 'Nagpur', state: 'Maharashtra', weight: 9 },
  { city: 'Ahmedabad', state: 'Gujarat', weight: 7 },
  { city: 'Bangalore', state: 'Karnataka', weight: 5 },
];

const CUSTOMER_POOL = [
  { id: 'CUST-1001', name: 'Aarav Deshmukh', city: 'Pune', state: 'Maharashtra' },
  { id: 'CUST-1002', name: 'Pooja Kulkarni', city: 'Pune', state: 'Maharashtra' },
  { id: 'CUST-1003', name: 'Rohan Mehta', city: 'Mumbai', state: 'Maharashtra' },
  { id: 'CUST-1004', name: 'Ananya Sharma', city: 'Pune', state: 'Maharashtra' },
  { id: 'CUST-1005', name: 'Priya Joshi', city: 'Nashik', state: 'Maharashtra' },
  { id: 'CUST-1006', name: 'Neha Patil', city: 'Pune', state: 'Maharashtra' },
  { id: 'CUST-1007', name: 'Vikram Shinde', city: 'Nagpur', state: 'Maharashtra' },
  { id: 'CUST-1008', name: 'Aditi Shah', city: 'Ahmedabad', state: 'Gujarat' },
  { id: 'CUST-1009', name: 'Tanvi Gaikwad', city: 'Pune', state: 'Maharashtra' },
  { id: 'CUST-1010', name: 'Snehal More', city: 'Mumbai', state: 'Maharashtra' },
  { id: 'CUST-1011', name: 'Kavita Rao', city: 'Bangalore', state: 'Karnataka' },
  { id: 'CUST-1012', name: 'Rahul Varma', city: 'Mumbai', state: 'Maharashtra' },
  { id: 'CUST-1013', name: 'Meera Iyer', city: 'Bangalore', state: 'Karnataka' },
  { id: 'CUST-1014', name: 'Divya Nair', city: 'Pune', state: 'Maharashtra' },
  { id: 'CUST-1015', name: 'Gaurav Jadhav', city: 'Pune', state: 'Maharashtra' },
  { id: 'CUST-1016', name: 'Pallavi Chavan', city: 'Nashik', state: 'Maharashtra' },
  { id: 'CUST-1017', name: 'Amitabh Sen', city: 'Mumbai', state: 'Maharashtra' },
  { id: 'CUST-1018', name: 'Shreya Patel', city: 'Ahmedabad', state: 'Gujarat' },
  { id: 'CUST-1019', name: 'Siddharth Pawar', city: 'Pune', state: 'Maharashtra' },
  { id: 'CUST-1020', name: 'Ishita Roy', city: 'Nagpur', state: 'Maharashtra' },
];

/**
 * Generate 1,248 realistic orders spanning past 120 days
 * Calibrated precisely to target:
 * - Orders: 1,248
 * - Total Revenue: ~₹8,42,500
 * - AOV: ~₹675
 * - Repeat customer percentage: ~32%
 */
export function generateDemoOrders(): Order[] {
  const orders: Order[] = [];
  const TOTAL_ORDERS = 1248;

  // Pseudo-random deterministic generator for consistent reproducibility
  let seed = 42;
  function random(): number {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  }

  // Base date: 2026-09-30 (local current time anchor)
  const now = new Date('2026-09-30T12:00:00Z');

  // Customer pool of ~450 customers (some with repeat orders to achieve ~32% repeat rate)
  const totalCustomers = 450;
  const customersList: { id: string; name: string; city: string; state: string }[] = [];

  for (let i = 0; i < totalCustomers; i++) {
    const cityObj = pickWeighted(CITIES, random);
    const firstName = ['Aarav', 'Pooja', 'Rohan', 'Ananya', 'Priya', 'Neha', 'Vikram', 'Aditi', 'Snehal', 'Tanvi', 'Kavita', 'Rahul', 'Divya', 'Gaurav', 'Pallavi', 'Shreya', 'Siddharth', 'Ishita', 'Arjun', 'Manish', 'Kalyani', 'Nisha', 'Sunil', 'Bhavna'][i % 24];
    const lastName = ['Deshmukh', 'Kulkarni', 'Mehta', 'Sharma', 'Joshi', 'Patil', 'Shinde', 'Shah', 'More', 'Gaikwad', 'Rao', 'Varma', 'Chavan', 'Pawar', 'Nair', 'Patel', 'Jadhav', 'Bhat', 'Tambe', 'Sawant'][i % 20];
    customersList.push({
      id: `CUST-${1000 + i}`,
      name: `${firstName} ${lastName}`,
      city: cityObj.city,
      state: cityObj.state,
    });
  }

  // Define product probabilities matching target units
  const productWeights = CATALOG_PRODUCTS.map((p) => ({
    product: p,
    weight: p.targetUnits,
  }));

  for (let i = 1; i <= TOTAL_ORDERS; i++) {
    const orderId = `ORD-2026-${10000 + i}`;

    // Order date distributed over last 120 days with slight upward trend in recent 30 days
    const dayOffset = Math.floor(random() * 120);
    const orderDateObj = new Date(now.getTime() - dayOffset * 24 * 60 * 60 * 1000);
    const orderDate = orderDateObj.toISOString().split('T')[0];

    // Pick product with weight
    const selectedProd = pickWeighted(productWeights, random).product;

    // Quantity usually 1 (85%), sometimes 2 (12%), rarely 3 (3%)
    const qRand = random();
    const quantity = qRand < 0.85 ? 1 : qRand < 0.97 ? 2 : 3;

    // Slight variance in unit price based on seasonal discount (± 5%)
    const priceVariance = (random() * 0.1 - 0.05);
    const unitPrice = Math.round((selectedProd.basePrice * (1 + priceVariance)) / 10) * 10;
    const totalAmount = quantity * unitPrice;

    // Pick customer: 32% probability from the first 140 customers (creating repeat buyers)
    let customer;
    if (random() < 0.38) {
      customer = customersList[Math.floor(random() * 140)];
    } else {
      customer = customersList[Math.floor(random() * totalCustomers)];
    }

    // Payment status: 86% Completed, 10% COD, 4% Pending
    const payRand = random();
    const paymentStatus: Order['payment_status'] =
      payRand < 0.86 ? 'Completed' : payRand < 0.96 ? 'COD' : 'Pending';

    // Sales channel
    const channelRand = random();
    const salesChannel =
      channelRand < 0.55 ? 'Own Website' : channelRand < 0.80 ? 'WhatsApp / Instagram' : 'IndiaMART Inquiries';

    orders.push({
      order_id: orderId,
      order_date: orderDate,
      customer_id: customer.id,
      customer_name: customer.name,
      customer_email: `${customer.name.toLowerCase().replace(/\s+/g, '.')}@example.com`,
      product_id: selectedProd.id,
      product_name: selectedProd.name,
      category: selectedProd.category,
      quantity,
      unit_price: unitPrice,
      total_amount: totalAmount,
      city: customer.city,
      state: customer.state,
      payment_status: paymentStatus,
      sales_channel: salesChannel,
      stock_available: selectedProd.stock,
    });
  }

  // Sort by date ascending
  return orders.sort((a, b) => a.order_date.localeCompare(b.order_date));
}

function pickWeighted<T extends { weight: number }>(items: T[], randomFn: () => number): T {
  const totalWeight = items.reduce((sum, item) => sum + item.weight, 0);
  let threshold = randomFn() * totalWeight;
  for (const item of items) {
    threshold -= item.weight;
    if (threshold <= 0) return item;
  }
  return items[items.length - 1];
}

export const DEMO_ORDERS: Order[] = generateDemoOrders();
