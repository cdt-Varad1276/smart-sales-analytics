import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  FileSpreadsheet,
  ShoppingBag,
  Globe,
  UploadCloud,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  ShieldCheck,
  Download,
  Database,
  Layers,
} from 'lucide-react';
import { downloadSampleCsv } from '../../data/sampleCsv';

export const DataSourcesPage: React.FC = () => {
  const {
    businessProfile,
    orders,
    openUploadModal,
    resetToDemoData,
    openIntegrationModal,
    showToast,
  } = useApp();

  const handleRefresh = () => {
    resetToDemoData();
    showToast('Data refreshed successfully.', 'info');
  };

  const integrations = [
    {
      id: 'csv',
      name: 'Excel / CSV File',
      category: 'Direct Spreadsheet Upload',
      status: 'Connected',
      statusColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      lastSync: 'Active Session',
      recordsCount: `${orders.length} orders registered`,
      description: `Active source: ${businessProfile.dataSourceName}. Validated columns include order_id, product, price, quantity, city, and stock.`,
      icon: FileSpreadsheet,
      action: openUploadModal,
      actionLabel: 'Upload New File',
    },
    {
      id: 'indiamart',
      name: 'IndiaMART',
      category: 'B2B Marketplace & Leads',
      status: 'Demo Integration',
      statusColor: 'bg-blue-50 text-blue-700 border-blue-200',
      lastSync: 'Not Connected',
      recordsCount: 'Simulated API Schema',
      description: 'Reads verified buyer inquiries, quotation responses, and confirmed order dispatch entries from IndiaMART Seller CRM.',
      icon: ShoppingBag,
      action: () =>
        openIntegrationModal({
          name: 'IndiaMART',
          status: 'Demo Integration',
          description:
            'IndiaMART Seller CRM sync parses buyer lead inquiries, quotation statuses, and confirmed dispatches to calculate category demand and regional lead velocity.',
        }),
      actionLabel: 'Configure Connect',
    },
    {
      id: 'justdial',
      name: 'Justdial',
      category: 'Local Search & Business Leads',
      status: 'Demo Integration',
      statusColor: 'bg-blue-50 text-blue-700 border-blue-200',
      lastSync: 'Not Connected',
      recordsCount: 'Simulated API Schema',
      description: 'Tracks local inbound telephone inquiries and verified chat leads to anticipate regional demand spikes.',
      icon: Globe,
      action: () =>
        openIntegrationModal({
          name: 'Justdial',
          status: 'Demo Integration',
          description:
            'Justdial Merchant sync integrates phone and WhatsApp inquiry logs to help local sellers identify peak seasonal inquiry periods.',
        }),
      actionLabel: 'Configure Connect',
    },
    {
      id: 'shopify',
      name: 'Shopify',
      category: 'E-commerce Platform',
      status: 'Coming Soon',
      statusColor: 'bg-slate-100 text-slate-600 border-slate-200',
      lastSync: 'Planned Q4',
      recordsCount: 'Automatic Webhook Sync',
      description: 'Direct OAuth sync for Shopify stores to stream transactions and warehouse inventory levels.',
      icon: ShoppingBag,
      action: () =>
        openIntegrationModal({
          name: 'Shopify',
          status: 'Coming Soon',
          description:
            'Direct Shopify OAuth app is currently in active development. Small sellers can currently export their Shopify Orders CSV and upload instantly into SmartSell.',
        }),
      actionLabel: 'Notify Me',
    },
    {
      id: 'woocommerce',
      name: 'WooCommerce',
      category: 'WordPress Storefront',
      status: 'Coming Soon',
      statusColor: 'bg-slate-100 text-slate-600 border-slate-200',
      lastSync: 'Planned Q4',
      recordsCount: 'REST API Sync',
      description: 'Automated sync with self-hosted WordPress/WooCommerce instances via consumer API keys.',
      icon: Globe,
      action: () =>
        openIntegrationModal({
          name: 'WooCommerce',
          status: 'Coming Soon',
          description:
            'WooCommerce REST API token sync is planned for Q4. Use the Excel/CSV exporter to process WooCommerce data today.',
        }),
      actionLabel: 'Notify Me',
    },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Data Sources & Integrations
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Manage your connected business data streams, spreadsheet uploads, and marketplace pipelines.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={openUploadModal}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-sm shadow-blue-500/20 transition-colors"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Upload New Data</span>
          </button>

          <button
            onClick={handleRefresh}
            className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-lg border border-slate-200 shadow-2xs transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
            <span>Refresh Data</span>
          </button>
        </div>
      </div>

      {/* Integration Cards List */}
      <div className="space-y-3.5">
        {integrations.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.id}
              className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-slate-300 transition-colors"
            >
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-700 shrink-0">
                  <Icon className="w-5 h-5 text-slate-600" />
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-slate-900">{item.name}</h3>
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${item.statusColor}`}>
                      {item.status}
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 mt-0.5">
                    {item.category} • <span className="text-slate-700 font-medium">{item.recordsCount}</span>
                  </p>

                  <p className="text-xs text-slate-600 mt-2 max-w-xl leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0 self-end sm:self-center">
                {item.id === 'csv' && (
                  <button
                    onClick={downloadSampleCsv}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-1"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Template</span>
                  </button>
                )}

                <button
                  onClick={item.action}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg border border-slate-200 transition-colors"
                >
                  {item.actionLabel}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Schema Mapping & Column Health Card */}
      <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900">Standard Data Schema & Field Health</h3>
          </div>
          <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
            Validated CSV Structure
          </span>
        </div>

        <p className="text-xs text-slate-600">
          SmartSell analyzes tabular sales files with automatic header mapping. The standard fields are:
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          {[
            { field: 'order_id', status: 'Required', desc: 'Unique transaction ID' },
            { field: 'order_date', status: 'Required', desc: 'ISO Date YYYY-MM-DD' },
            { field: 'product_name', status: 'Required', desc: 'Item label / SKU' },
            { field: 'quantity', status: 'Required', desc: 'Units purchased' },
            { field: 'unit_price', status: 'Required', desc: 'Price per unit' },
            { field: 'city', status: 'Recommended', desc: 'Delivery location' },
            { field: 'customer_name', status: 'Recommended', desc: 'Customer tracking' },
            { field: 'stock_available', status: 'Optional', desc: 'Enables stockout alerts' },
          ].map((col, idx) => (
            <div key={idx} className="p-2.5 rounded-lg bg-slate-50 border border-slate-200/80">
              <div className="flex items-center justify-between mb-1">
                <code className="font-mono text-[11px] font-bold text-slate-800">{col.field}</code>
                <span className={`text-[9px] font-semibold px-1 rounded ${
                  col.status === 'Required' ? 'bg-blue-100 text-blue-700' : 'bg-slate-200 text-slate-600'
                }`}>
                  {col.status}
                </span>
              </div>
              <span className="text-[10px] text-slate-500 block">{col.desc}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Security Statement */}
      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 flex items-start gap-2.5">
        <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <strong className="text-slate-800">Security & Privacy Assurance:</strong> Your business sales data is parsed and evaluated locally in your browser session to calculate business intelligence KPIs. We do not store third-party credentials, scrape private customer contact details, or sell marketplace transaction histories.
        </div>
      </div>
    </div>
  );
};
