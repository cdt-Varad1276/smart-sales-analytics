import React from 'react';
import { useApp } from '../../context/AppContext';
import { Lightbulb, ArrowRight, TrendingUp, MapPin, Boxes, Sparkles, CheckCircle2 } from 'lucide-react';
import { PageView } from '../../types';

export const InsightsPanel: React.FC = () => {
  const { dashboardInsights, setCurrentPage, productMetrics, openProductDetail } = useApp();

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'growth':
        return <TrendingUp className="w-4 h-4 text-emerald-600" />;
      case 'location':
        return <MapPin className="w-4 h-4 text-blue-600" />;
      case 'inventory':
        return <Boxes className="w-4 h-4 text-amber-600" />;
      default:
        return <Sparkles className="w-4 h-4 text-indigo-600" />;
    }
  };

  const handleActionClick = (targetPage?: string, targetProductId?: string) => {
    if (targetProductId) {
      const prod = productMetrics.find((p) => p.productId === targetProductId);
      if (prod) {
        openProductDetail(prod);
        return;
      }
    }
    if (targetPage) {
      setCurrentPage(targetPage as PageView);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
      {/* Header */}
      <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600">
            <Lightbulb className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Diagnostic Insights & Decision Support
            </h3>
            <p className="text-xs text-slate-500">
              3 important things we found in your sales and inventory data
            </p>
          </div>
        </div>

        <button
          onClick={() => setCurrentPage('recommendations')}
          className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 hover:underline"
        >
          <span>View all recommendations</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Insights Cards Grid */}
      <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        {dashboardInsights.slice(0, 3).map((item, idx) => (
          <div
            key={item.id || idx}
            className="p-4 bg-slate-50/70 hover:bg-slate-50 rounded-xl border border-slate-200 flex flex-col justify-between transition-all hover:shadow-xs group"
          >
            <div>
              {/* Badge & Icon */}
              <div className="flex items-center justify-between mb-2.5">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-md bg-white border border-slate-200 shadow-2xs">
                    {getInsightIcon(item.type)}
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Finding #{idx + 1}
                  </span>
                </div>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-100/70 text-blue-800 border border-blue-200">
                  {item.impactLevel} Priority
                </span>
              </div>

              {/* Title */}
              <h4 className="text-xs font-bold text-slate-900 leading-snug">
                {item.title}
              </h4>

              {/* Why It Matters */}
              <div className="mt-2.5 pt-2 border-t border-slate-200/70 text-[11px] space-y-1">
                <span className="font-semibold text-slate-700 block">Why it matters:</span>
                <p className="text-slate-600 leading-relaxed">{item.whyItMatters}</p>
              </div>

              {/* Recommended Action */}
              <div className="mt-2 pt-2 border-t border-slate-200/70 text-[11px] space-y-1">
                <span className="font-semibold text-blue-900 block flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                  Recommended Action:
                </span>
                <p className="text-blue-950 leading-relaxed font-medium">
                  {item.recommendedAction}
                </p>
              </div>
            </div>

            {/* View Details Button */}
            <div className="pt-3 mt-3 border-t border-slate-200/60 flex items-center justify-between">
              <span className="text-[10px] text-slate-400">Decision Support</span>
              <button
                onClick={() => handleActionClick(item.targetPage, item.targetProductId)}
                className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 group-hover:translate-x-0.5 transition-transform"
              >
                <span>View Details</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
