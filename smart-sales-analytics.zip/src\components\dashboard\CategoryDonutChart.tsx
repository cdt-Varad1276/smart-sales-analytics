import React from 'react';
import { useApp } from '../../context/AppContext';
import { formatINR, formatPercent } from '../../utils/formatters';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const COLORS = ['#2563eb', '#3b82f6', '#60a5fa', '#93c5fd', '#bfdbfe', '#e2e8f0'];

export const CategoryDonutChart: React.FC = () => {
  const { categoryMetrics } = useApp();

  return (
    <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
      <div>
        <h3 className="text-sm font-bold text-slate-900">Revenue by Category</h3>
        <p className="text-xs text-slate-500">Share of sales across product lines</p>
      </div>

      <div className="h-52 w-full my-2 relative">
        {categoryMetrics.length === 0 ? (
          <div className="h-full flex items-center justify-center text-xs text-slate-400">
            No categories detected.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Tooltip
                contentStyle={{
                  backgroundColor: '#ffffff',
                  borderColor: '#e2e8f0',
                  borderRadius: '8px',
                  fontSize: '11px',
                }}
                formatter={(val: any, name: any, item: any) => [
                  `${formatINR(val)} (${item.payload.percentage.toFixed(1)}%)`,
                  name,
                ]}
              />
              <Pie
                data={categoryMetrics}
                dataKey="revenue"
                nameKey="category"
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={3}
              >
                {categoryMetrics.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* Custom Legend */}
      <div className="space-y-1.5 pt-2 border-t border-slate-100 max-h-36 overflow-y-auto">
        {categoryMetrics.map((item, idx) => (
          <div key={idx} className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 truncate">
              <span
                className="w-2.5 h-2.5 rounded-full shrink-0"
                style={{ backgroundColor: COLORS[idx % COLORS.length] }}
              />
              <span className="text-slate-700 truncate">{item.category}</span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className="font-semibold text-slate-900">{formatINR(item.revenue)}</span>
              <span className="text-[11px] text-slate-400">({item.percentage.toFixed(0)}%)</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
