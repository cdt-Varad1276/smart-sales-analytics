import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatINR, formatDate } from '../../utils/formatters';
import { Search, ShoppingBag, ArrowRight } from 'lucide-react';

export const RecentOrdersTable: React.FC = () => {
  const { filteredOrders, setCurrentPage } = useApp();
  const [searchTerm, setSearchTerm] = useState('');

  const filtered = filteredOrders.filter(
    (o) =>
      o.order_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.product_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.city.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const displayOrders = filtered.slice(-7).reverse();

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Completed':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'COD':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Pending':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Recent Customer Orders</h3>
          <p className="text-xs text-slate-500">Latest transactions registered in your business data</p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search order, customer, city..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 w-48 sm:w-60"
            />
          </div>

          <button
            onClick={() => setCurrentPage('sales-analytics')}
            className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 hover:underline whitespace-nowrap"
          >
            <span>All Orders</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600">
            <tr>
              <th className="py-2.5 px-3">Order ID</th>
              <th className="py-2.5 px-3">Date</th>
              <th className="py-2.5 px-3">Customer</th>
              <th className="py-2.5 px-3">Product</th>
              <th className="py-2.5 px-3">City</th>
              <th className="py-2.5 px-3 text-right">Amount</th>
              <th className="py-2.5 px-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {displayOrders.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-6 text-center text-xs text-slate-400">
                  No orders match search query.
                </td>
              </tr>
            ) : (
              displayOrders.map((o) => (
                <tr key={o.order_id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-2.5 px-3 font-mono text-[11px] font-medium text-slate-700">
                    {o.order_id}
                  </td>
                  <td className="py-2.5 px-3 text-slate-500 text-[11px]">
                    {formatDate(o.order_date)}
                  </td>
                  <td className="py-2.5 px-3 font-medium text-slate-900">
                    {o.customer_name}
                  </td>
                  <td className="py-2.5 px-3 text-slate-700">
                    <span className="font-medium text-slate-900">{o.product_name}</span>
                    <span className="text-[10px] text-slate-400 ml-1.5">×{o.quantity}</span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">
                    {o.city}
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                    {formatINR(o.total_amount)}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${getStatusBadge(o.payment_status)}`}>
                      {o.payment_status}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
