import Papa from 'papaparse';
import { Order } from '../types';

export interface CsvValidationReport {
  totalRowsDetected: number;
  validRowsCount: number;
  invalidRowsCount: number;
  detectedColumns: string[];
  mappedColumns: { [standardKey: string]: string | null };
  missingRequiredColumns: string[];
  hasStockColumn: boolean;
  warnings: string[];
}

export interface CsvParseResult {
  orders: Order[];
  report: CsvValidationReport;
}

// Flexible column name matching rules
const COLUMN_ALIASES: Record<string, string[]> = {
  order_id: ['order_id', 'orderid', 'order id', 'invoice_no', 'invoice id', 'id', 'order_no'],
  order_date: ['order_date', 'orderdate', 'order date', 'date', 'created_at', 'timestamp'],
  customer_id: ['customer_id', 'customerid', 'customer id', 'client_id', 'user_id'],
  customer_name: ['customer_name', 'customername', 'customer name', 'customer', 'buyer', 'client_name'],
  product_id: ['product_id', 'productid', 'product id', 'sku', 'item_code', 'item_id'],
  product_name: ['product_name', 'productname', 'product name', 'item_name', 'product', 'title'],
  category: ['category', 'product_category', 'item_category', 'department', 'type'],
  quantity: ['quantity', 'qty', 'units', 'count', 'quantity_sold'],
  unit_price: ['unit_price', 'unitprice', 'unit price', 'price', 'rate', 'item_price'],
  city: ['city', 'location', 'town', 'delivery_city', 'shipping_city'],
  state: ['state', 'province', 'region', 'shipping_state'],
  payment_status: ['payment_status', 'status', 'payment', 'order_status'],
  stock_available: ['stock_available', 'stock', 'inventory', 'current_stock', 'quantity_available', 'stock_units'],
};

function normalizeHeader(header: string): string {
  return header.trim().toLowerCase().replace(/[\s_-]+/g, '');
}

function findBestMatch(headerList: string[], aliases: string[]): string | null {
  const normalizedAliases = aliases.map(normalizeHeader);
  for (const header of headerList) {
    const normalized = normalizeHeader(header);
    if (normalizedAliases.includes(normalized)) {
      return header;
    }
  }
  // Substring match fallback
  for (const header of headerList) {
    const normalized = normalizeHeader(header);
    for (const alias of normalizedAliases) {
      if (normalized.includes(alias) || alias.includes(normalized)) {
        return header;
      }
    }
  }
  return null;
}

export function parseCsvFile(file: File): Promise<CsvParseResult> {
  return new Promise((resolve, reject) => {
    Papa.parse<Record<string, any>>(file, {
      header: true,
      skipEmptyLines: 'greedy',
      dynamicTyping: false,
      complete: (results) => {
        try {
          const rawData = results.data;
          const detectedColumns = results.meta.fields || [];

          const mapped: { [key: string]: string | null } = {};
          for (const [standardKey, aliasList] of Object.entries(COLUMN_ALIASES)) {
            mapped[standardKey] = findBestMatch(detectedColumns, aliasList);
          }

          const requiredColumns = ['order_id', 'product_name', 'unit_price', 'quantity'];
          const missingRequired = requiredColumns.filter((col) => !mapped[col]);

          const warnings: string[] = [];
          if (!mapped['stock_available']) {
            warnings.push("Column 'stock_available' was not detected. Inventory stockout risk insights will indicate missing stock data.");
          }
          if (!mapped['city']) {
            warnings.push("Column 'city' was not detected. Orders will be assigned to 'Direct Online'.");
          }
          if (!mapped['customer_name'] && !mapped['customer_id']) {
            warnings.push("Neither 'customer_name' nor 'customer_id' detected. Customer repeat metrics will be estimated.");
          }

          const validOrders: Order[] = [];
          let invalidRows = 0;

          rawData.forEach((row, index) => {
            const getVal = (stdKey: string) => {
              const actualCol = mapped[stdKey];
              return actualCol ? row[actualCol] : undefined;
            };

            const rawOrderId = getVal('order_id') || `ORD-ROW-${index + 1}`;
            const rawProductName = getVal('product_name') || getVal('product_id') || 'General Item';
            const rawPrice = parseFloat(String(getVal('unit_price')).replace(/[^0-9.-]+/g, ''));
            const rawQty = parseInt(String(getVal('quantity')).replace(/[^0-9.-]+/g, ''), 10);

            if (isNaN(rawPrice) || isNaN(rawQty) || rawPrice <= 0 || rawQty <= 0) {
              invalidRows++;
              return;
            }

            // Parse Date
            let rawDateStr = String(getVal('order_date') || '').trim();
            let parsedDate = '2026-09-01';
            if (rawDateStr) {
              const d = new Date(rawDateStr);
              if (!isNaN(d.getTime())) {
                parsedDate = d.toISOString().split('T')[0];
              }
            }

            const rawStock = getVal('stock_available');
            const stockParsed = rawStock !== undefined && rawStock !== null && rawStock !== ''
              ? parseInt(String(rawStock).replace(/[^0-9.-]+/g, ''), 10)
              : undefined;

            const customerName = String(getVal('customer_name') || `Customer-${(index % 200) + 1}`).trim();
            const customerId = String(getVal('customer_id') || `CUST-${customerName.replace(/[^a-zA-Z0-9]/g, '').slice(0, 8)}`).trim();

            const order: Order = {
              order_id: String(rawOrderId).trim(),
              order_date: parsedDate,
              customer_id: customerId,
              customer_name: customerName,
              product_id: String(getVal('product_id') || `PRD-${rawProductName.replace(/[^a-zA-Z0-9]/g, '').slice(0, 8).toUpperCase()}`),
              product_name: rawProductName.trim(),
              category: String(getVal('category') || 'General').trim(),
              quantity: rawQty,
              unit_price: rawPrice,
              total_amount: rawQty * rawPrice,
              city: String(getVal('city') || 'Pune').trim(),
              state: String(getVal('state') || 'Maharashtra').trim(),
              payment_status: (['Completed', 'COD', 'Pending'].includes(String(getVal('payment_status')))
                ? getVal('payment_status')
                : 'Completed') as Order['payment_status'],
              stock_available: !isNaN(Number(stockParsed)) ? Number(stockParsed) : undefined,
            };

            validOrders.push(order);
          });

          const report: CsvValidationReport = {
            totalRowsDetected: rawData.length,
            validRowsCount: validOrders.length,
            invalidRowsCount: invalidRows,
            detectedColumns,
            mappedColumns: mapped,
            missingRequiredColumns: missingRequired,
            hasStockColumn: !!mapped['stock_available'],
            warnings,
          };

          resolve({ orders: validOrders, report });
        } catch (err: any) {
          reject(new Error(`Failed to parse CSV: ${err.message}`));
        }
      },
      error: (error) => {
        reject(new Error(`CSV reading error: ${error.message}`));
      },
    });
  });
}
