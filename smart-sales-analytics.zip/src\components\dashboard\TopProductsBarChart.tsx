import React from 'react';
import { useApp } from '../../context/AppContext';
import { formatINR, formatNumber } from '../../utils/formatters';
import { ArrowUpRight, ArrowRight, Package } from 'lucide-react';

export const TopProductsBarChart: React.FC = () => {
  const { productMetrics, openProductDetail, setCurrentPage } = useApp();

  const topProducts = productMetrics.slice(0, 5);
  const maxRevenue = topProducts[0]?.revenue || 1;

  return (
    <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Top Products by Revenue</h3>
          <p className="text-xs text-slate-500">Highest grossing items in current catalog</p>
        </div>
        <button
          onClick={() => setCurrentPage('products')}
          className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 hover:underline"
        >
          <span>View catalog</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="space-y-3 my-2">
        {topProducts.map((p, idx) => {
          const percentage = Math.round((p.revenue / maxRevenue) * 100);

          return (
            <div
              key={p.productId || idx}
              onClick={() => openProductDetail(p)}
              className="group cursor-pointer p-2 rounded-lg hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center justify-between text-xs mb-1">
                <div className="flex items-center gap-2 truncate">
                  <span className="w-4 h-4 rounded bg-slate-100 text-slate-500 font-mono text-[10px] flex items-center justify-center font-bold shrink-0">
                    {idx + 1}
                  </span>
                  <span className="font-semibold text-slate-800 group-hover:text-blue-600 transition-colors truncate">
                    {p.productName}
                  </span>
                  <span className="text-[10px] text-slate-400">({p.category})</span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="font-bold text-slate-900">{formatINR(p.revenue)}</span>
                  <span className="text-[11px] text-slate-500 font-medium">({formatNumber(p.unitsSold)} units)</span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-600 rounded-full group-hover:bg-blue-700 transition-all duration-300"
                  style={{ width: `${percentage}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>

      <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-400 flex items-center justify-between">
        <span>Click any product for trend & inventory drilldown</span>
        <span>{productMetrics.length} total SKUs</span>
      </div>
    </div>
  );
};
