import { DEMO_ORDERS } from './demoData';
import { Order } from '../types';

export function convertOrdersToCsv(orders: Order[]): string {
  const headers = [
    'order_id',
    'order_date',
    'customer_id',
    'customer_name',
    'product_id',
    'product_name',
    'category',
    'quantity',
    'unit_price',
    'city',
    'state',
    'payment_status',
    'stock_available',
  ];

  const rows = orders.map((order) => [
    order.order_id,
    order.order_date,
    order.customer_id,
    `"${order.customer_name.replace(/"/g, '""')}"`,
    order.product_id,
    `"${order.product_name.replace(/"/g, '""')}"`,
    `"${order.category.replace(/"/g, '""')}"`,
    order.quantity,
    order.unit_price,
    order.city,
    order.state,
    order.payment_status,
    order.stock_available ?? '',
  ]);

  return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
}

export function downloadSampleCsv(): void {
  // Take a clean slice of demo orders or all 1,248 orders
  const csvContent = convertOrdersToCsv(DEMO_ORDERS);
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', 'urban_threads_sales_sample.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
