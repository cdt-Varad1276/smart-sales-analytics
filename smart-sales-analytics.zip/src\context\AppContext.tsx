import React, { createContext, useContext, useState, useMemo } from 'react';
import {
  BusinessProfile,
  Order,
  PageView,
  NotificationItem,
  ProductMetric,
  BusinessInsight,
  BusinessRecommendation,
} from '../types';
import { DEMO_ORDERS, initialBusinessProfile } from '../data/demoData';
import {
  calculateOverviewKPIs,
  calculateProductMetrics,
  calculateCityMetrics,
  calculateCategoryMetrics,
  calculateCustomerMetrics,
  filterOrdersByDateRange,
  OverviewMetrics,
} from '../utils/analyticsEngine';
import {
  generateDashboardInsights,
  generateActionableRecommendations,
} from '../utils/recommendationEngine';

interface ToastState {
  id: string;
  message: string;
  type: 'success' | 'info' | 'warning' | 'error';
}

interface AppContextType {
  // Auth & Profile
  isAuthenticated: boolean;
  businessProfile: BusinessProfile;
  currentPage: PageView;
  setCurrentPage: (page: PageView) => void;
  login: (email: string) => void;
  logout: () => void;
  register: (name: string, email: string) => void;
  updateBusinessProfile: (updates: Partial<BusinessProfile>) => void;

  // Data & Calculations
  orders: Order[];
  filteredOrders: Order[];
  dateRange: 'all' | '30d' | '90d' | 'year';
  setDateRange: (range: 'all' | '30d' | '90d' | 'year') => void;
  overviewMetrics: OverviewMetrics;
  productMetrics: ProductMetric[];
  cityMetrics: ReturnType<typeof calculateCityMetrics>;
  categoryMetrics: ReturnType<typeof calculateCategoryMetrics>;
  customerData: ReturnType<typeof calculateCustomerMetrics>;
  dashboardInsights: BusinessInsight[];
  recommendations: BusinessRecommendation[];

  // Actions
  loadUploadedOrders: (orders: Order[], sourceName: string) => void;
  resetToDemoData: () => void;
  startDemoMode: () => void;

  // Modals & UI States
  isUploadModalOpen: boolean;
  openUploadModal: () => void;
  closeUploadModal: () => void;

  selectedProductForDetail: ProductMetric | null;
  openProductDetail: (product: ProductMetric) => void;
  closeProductDetail: () => void;

  selectedProductForReorder: ProductMetric | null;
  openReorderCalculator: (product: ProductMetric) => void;
  closeReorderCalculator: () => void;

  isExportReportModalOpen: boolean;
  openExportReportModal: () => void;
  closeExportReportModal: () => void;

  selectedIntegration: { name: string; status: string; description: string } | null;
  openIntegrationModal: (integration: { name: string; status: string; description: string }) => void;
  closeIntegrationModal: () => void;

  // Notifications
  notifications: NotificationItem[];
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;

  // Toast
  toast: ToastState | null;
  showToast: (message: string, type?: ToastState['type']) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    title: 'Critical Inventory Alert',
    message: 'Cotton Kurti stock is running low (18 units, ~6 days left).',
    type: 'inventory',
    timestamp: '15 mins ago',
    read: false,
    linkPage: 'inventory',
  },
  {
    id: 'notif-2',
    title: 'Monthly Revenue Growth',
    message: 'Overall revenue increased +12.4% vs the prior comparable period.',
    type: 'sales',
    timestamp: '2 hours ago',
    read: false,
    linkPage: 'sales-analytics',
  },
  {
    id: 'notif-3',
    title: 'Demand Forecast Available',
    message: '30-day projected demand model computed with high confidence.',
    type: 'forecast',
    timestamp: 'Yesterday',
    read: true,
    linkPage: 'forecast',
  },
  {
    id: 'notif-4',
    title: 'Top Geographic Market',
    message: 'Pune continues to lead sales volume with 42% of orders.',
    type: 'sales',
    timestamp: '2 days ago',
    read: true,
    linkPage: 'sales-analytics',
  },
];

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true);
  const [businessProfile, setBusinessProfile] = useState<BusinessProfile>(initialBusinessProfile);
  const [currentPage, setCurrentPage] = useState<PageView>('landing');
  const [orders, setOrders] = useState<Order[]>(DEMO_ORDERS);
  const [dateRange, setDateRange] = useState<'all' | '30d' | '90d' | 'year'>('all');

  // Modals state
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [selectedProductForDetail, setSelectedProductForDetail] = useState<ProductMetric | null>(null);
  const [selectedProductForReorder, setSelectedProductForReorder] = useState<ProductMetric | null>(null);
  const [isExportReportModalOpen, setIsExportReportModalOpen] = useState(false);
  const [selectedIntegration, setSelectedIntegration] = useState<{
    name: string;
    status: string;
    description: string;
  } | null>(null);

  // Notifications
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  // Toast
  const [toast, setToast] = useState<ToastState | null>(null);

  const showToast = (message: string, type: ToastState['type'] = 'info') => {
    const id = Date.now().toString();
    setToast({ id, message, type });
    setTimeout(() => {
      setToast((prev) => (prev?.id === id ? null : prev));
    }, 4000);
  };

  // Filtered orders by date range
  const filteredOrders = useMemo(() => {
    return filterOrdersByDateRange(orders, dateRange);
  }, [orders, dateRange]);

  // Derived Analytics Engine Outputs
  const overviewMetrics = useMemo(() => {
    return calculateOverviewKPIs(filteredOrders);
  }, [filteredOrders]);

  const productMetrics = useMemo(() => {
    return calculateProductMetrics(filteredOrders);
  }, [filteredOrders]);

  const cityMetrics = useMemo(() => {
    return calculateCityMetrics(filteredOrders);
  }, [filteredOrders]);

  const categoryMetrics = useMemo(() => {
    return calculateCategoryMetrics(filteredOrders);
  }, [filteredOrders]);

  const customerData = useMemo(() => {
    return calculateCustomerMetrics(filteredOrders);
  }, [filteredOrders]);

  const dashboardInsights = useMemo(() => {
    return generateDashboardInsights(productMetrics, cityMetrics, filteredOrders);
  }, [productMetrics, cityMetrics, filteredOrders]);

  const recommendations = useMemo(() => {
    return generateActionableRecommendations(productMetrics, cityMetrics, filteredOrders);
  }, [productMetrics, cityMetrics, filteredOrders]);

  // Handlers
  const login = (email: string) => {
    setIsAuthenticated(true);
    setBusinessProfile((prev) => ({ ...prev, email }));
    setCurrentPage('dashboard');
    showToast(`Welcome back, ${businessProfile.name}!`, 'success');
  };

  const logout = () => {
    setIsAuthenticated(false);
    setCurrentPage('landing');
    showToast('You have been logged out securely.', 'info');
  };

  const register = (name: string, email: string) => {
    setIsAuthenticated(true);
    setBusinessProfile((prev) => ({
      ...prev,
      name: name || 'New Enterprise',
      email,
      isDemoData: false,
    }));
    setCurrentPage('business-setup');
    showToast('Account created successfully! Please set up your business details.', 'success');
  };

  const updateBusinessProfile = (updates: Partial<BusinessProfile>) => {
    setBusinessProfile((prev) => ({ ...prev, ...updates }));
    showToast('Business profile updated successfully.', 'success');
  };

  const loadUploadedOrders = (newOrders: Order[], sourceName: string) => {
    setOrders(newOrders);
    setBusinessProfile((prev) => ({
      ...prev,
      dataSourceName: sourceName,
      isDemoData: false,
    }));
    showToast(`Successfully imported and analyzed ${newOrders.length} orders!`, 'success');
  };

  const resetToDemoData = () => {
    setOrders(DEMO_ORDERS);
    setBusinessProfile(initialBusinessProfile);
    showToast('Reset to Urban Threads fictional demo dataset (1,248 orders).', 'info');
  };

  const startDemoMode = () => {
    setIsAuthenticated(true);
    setBusinessProfile(initialBusinessProfile);
    setOrders(DEMO_ORDERS);
    setCurrentPage('dashboard');
    showToast('Demo Mode active: Loaded Urban Threads data.', 'success');
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    showToast('All notifications marked as read.', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        isAuthenticated,
        businessProfile,
        currentPage,
        setCurrentPage,
        login,
        logout,
        register,
        updateBusinessProfile,
        orders,
        filteredOrders,
        dateRange,
        setDateRange,
        overviewMetrics,
        productMetrics,
        cityMetrics,
        categoryMetrics,
        customerData,
        dashboardInsights,
        recommendations,
        loadUploadedOrders,
        resetToDemoData,
        startDemoMode,
        isUploadModalOpen,
        openUploadModal: () => setIsUploadModalOpen(true),
        closeUploadModal: () => setIsUploadModalOpen(false),
        selectedProductForDetail,
        openProductDetail: (p) => setSelectedProductForDetail(p),
        closeProductDetail: () => setSelectedProductForDetail(null),
        selectedProductForReorder,
        openReorderCalculator: (p) => setSelectedProductForReorder(p),
        closeReorderCalculator: () => setSelectedProductForReorder(null),
        isExportReportModalOpen,
        openExportReportModal: () => setIsExportReportModalOpen(true),
        closeExportReportModal: () => setIsExportReportModalOpen(false),
        selectedIntegration,
        openIntegrationModal: (i) => setSelectedIntegration(i),
        closeIntegrationModal: () => setSelectedIntegration(null),
        notifications,
        markNotificationRead,
        markAllNotificationsRead,
        toast,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
