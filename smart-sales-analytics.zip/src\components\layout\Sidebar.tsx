import React from 'react';
import { useApp } from '../../context/AppContext';
import { PageView } from '../../types';
import {
  LayoutDashboard,
  TrendingUp,
  Package,
  Users,
  Boxes,
  LineChart,
  Lightbulb,
  Database,
  Settings,
  UploadCloud,
  RefreshCw,
  Sparkles,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';

interface NavItem {
  id: PageView;
  label: string;
  icon: React.ElementType;
  badge?: string | number;
  badgeColor?: string;
}

export const Sidebar: React.FC = () => {
  const {
    currentPage,
    setCurrentPage,
    businessProfile,
    recommendations,
    productMetrics,
    openUploadModal,
    resetToDemoData,
  } = useApp();

  const inventoryAlertsCount = productMetrics.filter(
    (p) => p.status === 'High Risk' || (p.daysRemaining !== null && p.daysRemaining <= 7)
  ).length;

  const navItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'sales-analytics', label: 'Sales Analytics', icon: TrendingUp },
    {
      id: 'products',
      label: 'Products',
      icon: Package,
      badge: `${productMetrics.length} SKUs`,
      badgeColor: 'bg-slate-100 text-slate-600',
    },
    { id: 'customers', label: 'Customers', icon: Users },
    {
      id: 'inventory',
      label: 'Inventory',
      icon: Boxes,
      badge: inventoryAlertsCount > 0 ? `${inventoryAlertsCount} alert` : undefined,
      badgeColor: 'bg-amber-100 text-amber-800',
    },
    { id: 'forecast', label: 'Demand Forecast', icon: LineChart },
    {
      id: 'recommendations',
      label: 'Recommendations',
      icon: Lightbulb,
      badge: recommendations.length > 0 ? recommendations.length : undefined,
      badgeColor: 'bg-blue-100 text-blue-700',
    },
    { id: 'data-sources', label: 'Data Sources', icon: Database },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col h-screen sticky top-0 shrink-0 z-30 select-none">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-100">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-sm shadow-blue-500/30">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-slate-900 tracking-tight text-base">SMARTSELL</span>
              <span className="text-[10px] font-semibold bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded border border-blue-200 uppercase tracking-wider">
                BI
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium leading-none mt-0.5">
              Decision Support for Sellers
            </p>
          </div>
        </div>
      </div>

      {/* Business Identity Pill */}
      <div className="px-4 py-3 bg-slate-50/70 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <div className="truncate">
            <p className="text-xs font-semibold text-slate-900 truncate">
              {businessProfile.name}
            </p>
            <p className="text-[11px] text-slate-500 truncate">
              {businessProfile.category} • {businessProfile.location.split(',')[0]}
            </p>
          </div>
          <span className="w-2 h-2 rounded-full bg-emerald-500 ring-4 ring-emerald-100 shrink-0" title="Connected" />
        </div>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <div className="px-3 pb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
          Core Analytics
        </div>
        {navItems.map((item) => {
          const isActive = currentPage === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => setCurrentPage(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all group ${
                isActive
                  ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/20'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon
                  className={`w-4 h-4 transition-colors ${
                    isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-700'
                  }`}
                />
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span
                  className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${
                    isActive ? 'bg-white/20 text-white' : item.badgeColor
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Quick Upload & Data Status Footer */}
      <div className="p-3 border-t border-slate-200 bg-slate-50/50 space-y-2">
        <button
          onClick={openUploadModal}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200 hover:bg-blue-100 rounded-lg transition-colors"
        >
          <UploadCloud className="w-4 h-4" />
          <span>Upload Sales CSV</span>
        </button>

        {businessProfile.isDemoData ? (
          <div className="p-2 bg-amber-50/60 rounded-md border border-amber-200/60 text-[11px] text-amber-900 flex items-start gap-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
            <div className="leading-tight">
              <span className="font-semibold">Demo Mode:</span> Urban Threads fictional dataset loaded.
            </div>
          </div>
        ) : (
          <button
            onClick={resetToDemoData}
            className="w-full flex items-center justify-center gap-1.5 px-2 py-1.5 text-[11px] text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded transition-colors"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Reset to Demo Data</span>
          </button>
        )}

        <div className="pt-1 flex items-center justify-between text-[10px] text-slate-400 px-1">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-slate-400" />
            Local BI processing
          </span>
          <span>v1.0 MVP</span>
        </div>
      </div>
    </aside>
  );
};
