import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { formatINR, formatNumber, formatDate } from '../../utils/formatters';
import { calculateRevenueTrends } from '../../utils/analyticsEngine';
import {
  TrendingUp,
  Filter,
  Search,
  Download,
  Calendar,
  Layers,
  MapPin,
  CreditCard,
  ArrowUpDown,
  ShoppingBag,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

export const SalesAnalyticsPage: React.FC = () => {
  const { filteredOrders, categoryMetrics, cityMetrics } = useApp();

  // Filters
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedCity, setSelectedCity] = useState<string>('All');
  const [selectedPaymentStatus, setSelectedPaymentStatus] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [trendView, setTrendView] = useState<'daily' | 'weekly' | 'monthly'>('weekly');

  // Filtered dataset
  const activeOrders = useMemo(() => {
    return filteredOrders.filter((o) => {
      const matchCategory = selectedCategory === 'All' || o.category === selectedCategory;
      const matchCity = selectedCity === 'All' || o.city === selectedCity;
      const matchPayment = selectedPaymentStatus === 'All' || o.payment_status === selectedPaymentStatus;
      const matchSearch =
        !searchTerm ||
        o.order_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        o.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        o.product_name.toLowerCase().includes(searchTerm.toLowerCase());
      return matchCategory && matchCity && matchPayment && matchSearch;
    });
  }, [filteredOrders, selectedCategory, selectedCity, selectedPaymentStatus, searchTerm]);

  // KPIs
  const totalRevenue = useMemo(() => activeOrders.reduce((acc, o) => acc + o.total_amount, 0), [activeOrders]);
  const totalOrders = useMemo(() => new Set(activeOrders.map((o) => o.order_id)).size, [activeOrders]);
  const totalUnits = useMemo(() => activeOrders.reduce((acc, o) => acc + o.quantity, 0), [activeOrders]);
  const aov = totalOrders > 0 ? Math.round(totalRevenue / totalOrders) : 0;
  const itemsPerOrder = totalOrders > 0 ? (totalUnits / totalOrders).toFixed(1) : '0';

  // Trends
  const trendData = calculateRevenueTrends(activeOrders, trendView);

  // Payment status distribution
  const paymentBreakdown = useMemo(() => {
    const map = new Map<string, number>();
    activeOrders.forEach((o) => {
      map.set(o.payment_status, (map.get(o.payment_status) || 0) + o.total_amount);
    });
    return Array.from(map.entries()).map(([status, amount]) => ({ status, amount }));
  }, [activeOrders]);

  const PAYMENT_COLORS: Record<string, string> = {
    Completed: '#10b981',
    COD: '#3b82f6',
    Pending: '#f59e0b',
  };

  // Distinct dropdown lists
  const categoriesList = ['All', ...Array.from(new Set(filteredOrders.map((o) => o.category)))];
  const citiesList = ['All', ...Array.from(new Set(filteredOrders.map((o) => o.city)))];
  const paymentList = ['All', 'Completed', 'COD', 'Pending'];

  // Table pagination
  const [currentPageNum, setCurrentPageNum] = useState(1);
  const pageSize = 10;
  const totalPages = Math.ceil(activeOrders.length / pageSize) || 1;
  const paginatedOrders = activeOrders.slice((currentPageNum - 1) * pageSize, currentPageNum * pageSize);

  return (
    <div className="space-y-6 pb-12">
      {/* Title */}
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
          Sales Analytics
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Detailed sales trends, transaction registers, and category velocity analysis.
        </p>
      </div>

      {/* Interactive Filters Strip */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
          <Filter className="w-3.5 h-3.5 text-blue-600" />
          <span>Filter Transactions</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <div>
            <label className="text-slate-500 text-[11px] block mb-1">Category</label>
            <select
              value={selectedCategory}
              onChange={(e) => {
                setSelectedCategory(e.target.value);
                setCurrentPageNum(1);
              }}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
            >
              {categoriesList.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-slate-500 text-[11px] block mb-1">Location / City</label>
            <select
              value={selectedCity}
              onChange={(e) => {
                setSelectedCity(e.target.value);
                setCurrentPageNum(1);
              }}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
            >
              {citiesList.map((city) => (
                <option key={city} value={city}>
                  {city}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-slate-500 text-[11px] block mb-1">Payment Method / Status</label>
            <select
              value={selectedPaymentStatus}
              onChange={(e) => {
                setSelectedPaymentStatus(e.target.value);
                setCurrentPageNum(1);
              }}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
            >
              {paymentList.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-slate-500 text-[11px] block mb-1">Search Keywords</label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Product, customer, ID..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPageNum(1);
                }}
                className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Filtered Summary KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Filtered Revenue</span>
          <span className="text-xl font-bold text-slate-900 block mt-1">{formatINR(totalRevenue)}</span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Orders Count</span>
          <span className="text-xl font-bold text-slate-900 block mt-1">{formatNumber(totalOrders)}</span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Average Order Value</span>
          <span className="text-xl font-bold text-slate-900 block mt-1">{formatINR(aov)}</span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Units Sold</span>
          <span className="text-xl font-bold text-slate-900 block mt-1">{formatNumber(totalUnits)}</span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs col-span-2 sm:col-span-1">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Avg Items / Order</span>
          <span className="text-xl font-bold text-slate-900 block mt-1">{itemsPerOrder} units</span>
        </div>
      </div>

      {/* Trend Chart with Granularity */}
      <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Sales Velocity Over Time</h3>
            <p className="text-xs text-slate-500">Revenue & volume trajectory</p>
          </div>

          <div className="flex items-center bg-slate-100 p-0.5 rounded-lg text-xs self-start sm:self-auto">
            <button
              onClick={() => setTrendView('daily')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${
                trendView === 'daily'
                  ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Daily
            </button>
            <button
              onClick={() => setTrendView('weekly')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${
                trendView === 'weekly'
                  ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Weekly
            </button>
            <button
              onClick={() => setTrendView('monthly')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${
                trendView === 'monthly'
                  ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Monthly
            </button>
          </div>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="salesGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563eb" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#2563eb" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="dateLabel" tick={{ fontSize: 11, fill: '#64748b' }} stroke="#cbd5e1" />
              <YAxis
                tick={{ fontSize: 11, fill: '#64748b' }}
                stroke="#cbd5e1"
                tickFormatter={(val) => `₹${val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val}`}
              />
              <Tooltip
                contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '8px', fontSize: '12px' }}
                formatter={(val: any) => [formatINR(val), 'Revenue']}
              />
              <Area type="monotone" dataKey="revenue" stroke="#2563eb" strokeWidth={2.5} fillOpacity={1} fill="url(#salesGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Payment Status & Category Share Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Payment Methods */}
        <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Payment Status Distribution</h3>
              <p className="text-xs text-slate-500">Completed vs COD vs Pending revenue</p>
            </div>
            <CreditCard className="w-4 h-4 text-slate-400" />
          </div>

          <div className="space-y-3 pt-2">
            {paymentBreakdown.map((item, idx) => {
              const share = totalRevenue > 0 ? (item.amount / totalRevenue) * 100 : 0;
              return (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800">{item.status}</span>
                    <span className="font-bold text-slate-900">
                      {formatINR(item.amount)} ({share.toFixed(1)}%)
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${share}%`,
                        backgroundColor: PAYMENT_COLORS[item.status] || '#64748b',
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Top Cities In Filtered View */}
        <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Regional Delivery Distribution</h3>
              <p className="text-xs text-slate-500">Orders grouped by shipping city</p>
            </div>
            <MapPin className="w-4 h-4 text-slate-400" />
          </div>

          <div className="space-y-2.5 pt-1">
            {cityMetrics.slice(0, 4).map((city, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs p-2 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-semibold text-slate-800">{city.city} ({city.state})</span>
                <div className="flex items-center gap-3">
                  <span className="text-slate-500">{city.orderCount} orders</span>
                  <span className="font-bold text-slate-900">{formatINR(city.revenue)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Transaction Register Table */}
      <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Sales Transactions Register</h3>
            <p className="text-xs text-slate-500">
              Showing {activeOrders.length} transaction records
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600">
              <tr>
                <th className="py-2.5 px-3">Order ID</th>
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Customer</th>
                <th className="py-2.5 px-3">Product Name</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3 text-right">Qty</th>
                <th className="py-2.5 px-3 text-right">Price</th>
                <th className="py-2.5 px-3 text-right">Total</th>
                <th className="py-2.5 px-3">City</th>
                <th className="py-2.5 px-3">Payment</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedOrders.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-8 text-center text-xs text-slate-400">
                    No orders matching selected filters.
                  </td>
                </tr>
              ) : (
                paginatedOrders.map((o) => (
                  <tr key={o.order_id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-2.5 px-3 font-mono text-[11px] font-medium text-slate-700">
                      {o.order_id}
                    </td>
                    <td className="py-2.5 px-3 text-slate-500 text-[11px]">
                      {formatDate(o.order_date)}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">
                      {o.customer_name}
                    </td>
                    <td className="py-2.5 px-3 text-slate-800 font-medium">
                      {o.product_name}
                    </td>
                    <td className="py-2.5 px-3 text-slate-500">
                      {o.category}
                    </td>
                    <td className="py-2.5 px-3 text-right font-medium text-slate-700">
                      {o.quantity}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-600">
                      {formatINR(o.unit_price)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                      {formatINR(o.total_amount)}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {o.city}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                        o.payment_status === 'Completed'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : o.payment_status === 'COD'
                          ? 'bg-blue-50 text-blue-700 border-blue-200'
                          : 'bg-amber-50 text-amber-700 border-amber-200'
                      }`}>
                        {o.payment_status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination controls */}
        {totalPages > 1 && (
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>
              Page {currentPageNum} of {totalPages}
            </span>
            <div className="flex items-center gap-1">
              <button
                disabled={currentPageNum === 1}
                onClick={() => setCurrentPageNum((p) => Math.max(1, p - 1))}
                className="px-2.5 py-1 rounded border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Previous
              </button>
              <button
                disabled={currentPageNum === totalPages}
                onClick={() => setCurrentPageNum((p) => Math.min(totalPages, p + 1))}
                className="px-2.5 py-1 rounded border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
