import React from 'react';
import { useApp } from '../../context/AppContext';
import { formatINR, formatNumber, formatPercent } from '../../utils/formatters';
import { calculateDemandForecasts } from '../../utils/analyticsEngine';
import {
  X,
  TrendingUp,
  Package,
  Boxes,
  MapPin,
  Calendar,
  AlertTriangle,
  Lightbulb,
  CheckCircle2,
  ArrowUpRight,
  ArrowDownRight,
  Calculator,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from 'recharts';

export const ProductDetailModal: React.FC = () => {
  const {
    selectedProductForDetail,
    closeProductDetail,
    orders,
    openReorderCalculator,
    setCurrentPage,
  } = useApp();

  if (!selectedProductForDetail) return null;

  const product = selectedProductForDetail;

  // Filter orders for this product
  const productOrders = orders.filter((o) => o.product_name === product.productName);

  // Compute forecast for this specific product
  const forecast = calculateDemandForecasts(orders, product.productName, 30);

  // Calculate city distribution for this product
  const cityCountMap = new Map<string, number>();
  productOrders.forEach((o) => {
    cityCountMap.set(o.city, (cityCountMap.get(o.city) || 0) + o.quantity);
  });
  const topCities = Array.from(cityCountMap.entries())
    .map(([city, units]) => ({ city, units }))
    .sort((a, b) => b.units - a.units)
    .slice(0, 4);

  // Prepare 30-day trend chart
  const dateMap = new Map<string, number>();
  productOrders.forEach((o) => {
    dateMap.set(o.order_date, (dateMap.get(o.order_date) || 0) + o.quantity);
  });
  const chartData = Array.from(dateMap.entries())
    .map(([date, units]) => ({ date: date.slice(5), units }))
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(-20);

  const isLowStock = product.daysRemaining !== null && product.daysRemaining <= 10;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100/70 border border-blue-200 flex items-center justify-center text-blue-700 font-bold text-sm">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">{product.productName}</h3>
                <span className="text-xs text-slate-400 font-mono">({product.productId})</span>
                <span className="text-[10px] font-semibold bg-slate-100 text-slate-700 px-2 py-0.5 rounded border border-slate-200">
                  {product.category}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Avg Selling Price: <span className="font-semibold text-slate-800">{formatINR(product.averagePrice)}</span> • Velocity: <span className="font-semibold text-slate-800">{product.velocity} units/day</span>
              </p>
            </div>
          </div>

          <button
            onClick={closeProductDetail}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Key Metric Tiles */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[11px] text-slate-500 font-medium block">Total Revenue</span>
              <span className="text-base font-bold text-slate-900 mt-0.5 block">
                {formatINR(product.revenue)}
              </span>
              <div className={`flex items-center gap-1 text-[11px] font-semibold mt-1 ${
                product.growthRate >= 0 ? 'text-emerald-600' : 'text-rose-600'
              }`}>
                {product.growthRate >= 0 ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                <span>{formatPercent(product.growthRate)} growth</span>
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[11px] text-slate-500 font-medium block">Units Sold</span>
              <span className="text-base font-bold text-slate-900 mt-0.5 block">
                {formatNumber(product.unitsSold)}
              </span>
              <span className="text-[11px] text-slate-500 mt-1 block">
                across {product.orderCount} orders
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[11px] text-slate-500 font-medium block">Current Stock</span>
              <span className="text-base font-bold text-slate-900 mt-0.5 block">
                {product.currentStock !== null ? `${product.currentStock} units` : 'Not Tracked'}
              </span>
              <span className={`text-[11px] font-semibold mt-1 block ${
                isLowStock ? 'text-rose-600 font-bold' : 'text-emerald-700'
              }`}>
                {product.daysRemaining !== null ? `~${product.daysRemaining} days left` : 'Add stock data'}
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[11px] text-slate-500 font-medium block">Product Status</span>
              <span className={`inline-block mt-1 text-xs font-semibold px-2 py-0.5 rounded-full border ${
                product.status === 'High Risk'
                  ? 'bg-rose-50 text-rose-700 border-rose-200'
                  : product.status === 'High Demand'
                  ? 'bg-blue-50 text-blue-700 border-blue-200'
                  : product.status === 'Review'
                  ? 'bg-amber-50 text-amber-700 border-amber-200'
                  : 'bg-emerald-50 text-emerald-700 border-emerald-200'
              }`}>
                {product.status}
              </span>
              <span className="text-[11px] text-slate-400 mt-1 block truncate">
                Top city: {product.topCity}
              </span>
            </div>
          </div>

          {/* Sales Trend Chart */}
          <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h4 className="text-xs font-bold text-slate-800">Recent Sales Velocity Trend</h4>
                <p className="text-[11px] text-slate-500">Daily units ordered across recent days</p>
              </div>
              <span className="text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded">
                {product.velocity} units / day
              </span>
            </div>

            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="prodGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2563eb" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="#2563eb" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#64748b' }} stroke="#cbd5e1" />
                  <YAxis tick={{ fontSize: 10, fill: '#64748b' }} stroke="#cbd5e1" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#ffffff', borderColor: '#cbd5e1', borderRadius: '8px', fontSize: '11px' }}
                    formatter={(val: any) => [`${val} units`, 'Sales']}
                  />
                  <Area type="monotone" dataKey="units" stroke="#2563eb" strokeWidth={2} fillOpacity={1} fill="url(#prodGradient)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Geographic Breakdown & Demand Forecast 2-Col */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Top Purchasing Cities */}
            <div className="p-4 bg-white rounded-xl border border-slate-200 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                <MapPin className="w-4 h-4 text-blue-600" />
                <span>Top Regional Markets</span>
              </div>
              <div className="space-y-2">
                {topCities.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs">
                    <span className="text-slate-700 font-medium">{item.city}</span>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-900">{item.units} units</span>
                      <span className="text-[10px] text-slate-400">
                        ({Math.round((item.units / product.unitsSold) * 100)}%)
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Demand Forecast Preview */}
            <div className="p-4 bg-white rounded-xl border border-slate-200 space-y-2.5">
              <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-blue-600" />
                  <span>30-Day Demand Forecast</span>
                </div>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                  forecast?.trend === 'Increasing'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : 'bg-slate-100 text-slate-700 border-slate-200'
                }`}>
                  {forecast?.trend || 'Stable'} Trend
                </span>
              </div>

              {forecast && (
                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-500">Expected Demand:</span>
                    <span className="font-bold text-slate-900">{forecast.forecastUnits} units</span>
                  </div>
                  <div className="flex items-center justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-500">Projected Revenue:</span>
                    <span className="font-bold text-slate-900">{formatINR(forecast.projectedRevenue)}</span>
                  </div>
                  <div className="flex items-center justify-between py-1">
                    <span className="text-slate-500">Uncertainty Range:</span>
                    <span className="text-slate-600">{forecast.confidenceInterval.min} - {forecast.confidenceInterval.max} units</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Actionable Decision Support Banner */}
          <div className="p-4 bg-blue-50/50 rounded-xl border border-blue-200 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-blue-900">
              <Lightbulb className="w-4 h-4 text-blue-600" />
              <span>Recommended Seller Action</span>
            </div>
            <p className="text-xs text-blue-950 leading-relaxed">
              {forecast?.recommendedAction || 'Monitor sales velocity on your weekly cycle.'}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={() => {
              closeProductDetail();
              setCurrentPage('forecast');
            }}
            className="text-xs text-blue-600 hover:text-blue-800 font-semibold hover:underline"
          >
            View full 90-day forecast model →
          </button>

          <div className="flex items-center gap-2">
            {product.currentStock !== null && (
              <button
                onClick={() => {
                  closeProductDetail();
                  openReorderCalculator(product);
                }}
                className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors shadow-sm shadow-blue-500/20"
              >
                <Calculator className="w-3.5 h-3.5" />
                <span>Calculate Reorder Quantity</span>
              </button>
            )}
            <button
              onClick={closeProductDetail}
              className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg border border-slate-200 transition-colors"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
