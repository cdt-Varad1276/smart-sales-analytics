import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  FileSpreadsheet,
  ShoppingBag,
  Globe,
  UploadCloud,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Download,
} from 'lucide-react';
import { downloadSampleCsv } from '../../data/sampleCsv';

export const DataConnectionPage: React.FC = () => {
  const { openUploadModal, startDemoMode, openIntegrationModal, setCurrentPage, businessProfile } = useApp();

  const sources = [
    {
      id: 'csv',
      name: 'Excel / CSV',
      type: 'Direct File Upload',
      status: 'Available',
      statusBadgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      description: 'Upload your sales register, offline invoices, or POS transaction export (.csv file).',
      icon: FileSpreadsheet,
      action: openUploadModal,
      buttonText: 'Upload Data',
      isPrimary: true,
    },
    {
      id: 'indiamart',
      name: 'IndiaMART',
      type: 'Marketplace Inquiries',
      status: 'Demo Integration',
      statusBadgeClass: 'bg-blue-50 text-blue-700 border-blue-200',
      description: 'Sync customer lead inquiries, quotation statuses, and verified product purchases.',
      icon: ShoppingBag,
      action: () =>
        openIntegrationModal({
          name: 'IndiaMART',
          status: 'Demo Integration',
          description:
            'IndiaMART Seller CRM sync parses buyer lead inquiries, quotation statuses, and confirmed dispatches to calculate category demand and regional lead velocity.',
        }),
      buttonText: 'Connect',
      isPrimary: false,
    },
    {
      id: 'justdial',
      name: 'Justdial',
      type: 'Local Search & Leads',
      status: 'Demo Integration',
      statusBadgeClass: 'bg-blue-50 text-blue-700 border-blue-200',
      description: 'Ingest verified phone calls, local search inquiries, and buyer intent logs.',
      icon: Globe,
      action: () =>
        openIntegrationModal({
          name: 'Justdial',
          status: 'Demo Integration',
          description:
            'Justdial Merchant sync integrates phone and WhatsApp inquiry logs to help local sellers identify peak seasonal inquiry periods.',
        }),
      buttonText: 'Connect',
      isPrimary: false,
    },
    {
      id: 'shopify',
      name: 'Shopify',
      type: 'Storefront Platform',
      status: 'Coming Soon',
      statusBadgeClass: 'bg-slate-100 text-slate-600 border-slate-200',
      description: 'Automated order and live stock webhooks for direct-to-consumer websites.',
      icon: ShoppingBag,
      action: () =>
        openIntegrationModal({
          name: 'Shopify',
          status: 'Coming Soon',
          description:
            'Direct Shopify OAuth app is currently in active development. Small sellers can currently export their Shopify Orders CSV and upload instantly into SmartSell.',
        }),
      buttonText: 'Connect',
      isPrimary: false,
    },
    {
      id: 'woocommerce',
      name: 'WooCommerce',
      type: 'WordPress Store',
      status: 'Coming Soon',
      statusBadgeClass: 'bg-slate-100 text-slate-600 border-slate-200',
      description: 'Automated sync via WooCommerce REST API keys for self-hosted stores.',
      icon: Globe,
      action: () =>
        openIntegrationModal({
          name: 'WooCommerce',
          status: 'Coming Soon',
          description:
            'WooCommerce REST API token sync is planned for Q4. Use the Excel/CSV exporter to process WooCommerce data today.',
        }),
      buttonText: 'Connect',
      isPrimary: false,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-6 max-w-5xl mx-auto font-sans">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 mb-2">
          <span className="text-xs font-bold text-blue-700 uppercase tracking-wider bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            Step 3 of 3: Data Connection
          </span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          Connect Your Business Data
        </h1>
        <p className="text-sm text-slate-600 mt-2">
          Bring your existing sales data into SmartSell Analytics to generate insights, inventory health alerts, and demand forecasts.
        </p>

        {/* Quick Demo Shortcut Banner */}
        <div className="mt-6 p-4 bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl border border-amber-200/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-left shadow-2xs">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-amber-100/80 text-amber-800 shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-amber-950">Don't have a CSV file ready right now?</h4>
              <p className="text-xs text-amber-800/90 mt-0.5">
                Load the realistic fictional dataset for <span className="font-semibold text-amber-950">"Urban Threads"</span> (Pune, 1,248 orders, 6 products) with one click.
              </p>
            </div>
          </div>

          <button
            onClick={startDemoMode}
            className="w-full sm:w-auto px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-lg transition-colors whitespace-nowrap shadow-sm shadow-amber-600/20"
          >
            Use Demo Business Data
          </button>
        </div>
      </div>

      {/* Connection Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sources.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.id}
              className={`p-5 rounded-2xl border transition-all flex flex-col justify-between ${
                item.isPrimary
                  ? 'bg-white border-blue-300 shadow-md ring-1 ring-blue-500/10'
                  : 'bg-white border-slate-200 hover:border-slate-300 shadow-2xs'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    item.isPrimary ? 'bg-blue-50 text-blue-600 border border-blue-200' : 'bg-slate-50 text-slate-600 border border-slate-200'
                  }`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${item.statusBadgeClass}`}>
                    {item.status}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900">{item.name}</h3>
                <span className="text-[11px] font-medium text-slate-400 block mb-2">{item.type}</span>
                <p className="text-xs text-slate-600 leading-relaxed">{item.description}</p>
              </div>

              <div className="pt-5 mt-4 border-t border-slate-100 flex items-center justify-between">
                {item.id === 'csv' ? (
                  <button
                    type="button"
                    onClick={downloadSampleCsv}
                    className="text-[11px] text-blue-600 hover:underline font-medium flex items-center gap-1"
                  >
                    <Download className="w-3 h-3" />
                    <span>Sample CSV</span>
                  </button>
                ) : (
                  <span className="text-[11px] text-slate-400">
                    {item.status.includes('Coming') ? 'Planned' : 'Supported'}
                  </span>
                )}

                <button
                  onClick={item.action}
                  className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 ${
                    item.isPrimary
                      ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-sm shadow-blue-500/20'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                  }`}
                >
                  <span>{item.buttonText}</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Security & Privacy Disclaimer */}
      <div className="mt-12 p-4 bg-white rounded-xl border border-slate-200 text-xs text-slate-500 flex items-center justify-between max-w-3xl mx-auto shadow-2xs">
        <div className="flex items-center gap-2.5">
          <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>
            <strong>Data Privacy:</strong> Your business records remain confidential and are processed in your local session. We do not store or sell individual customer information.
          </span>
        </div>
      </div>
    </div>
  );
};
