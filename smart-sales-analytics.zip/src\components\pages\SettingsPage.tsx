import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Store,
  MapPin,
  Tag,
  Coins,
  Bell,
  User,
  Shield,
  LogOut,
  Save,
  RefreshCw,
  Sparkles,
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { businessProfile, updateBusinessProfile, logout, resetToDemoData, showToast } = useApp();

  const [name, setName] = useState(businessProfile.name);
  const [category, setCategory] = useState(businessProfile.category);
  const [location, setLocation] = useState(businessProfile.location);
  const [email, setEmail] = useState(businessProfile.email);
  const [currency, setCurrency] = useState(businessProfile.currency);

  const [lowStockAlertDays, setLowStockAlertDays] = useState(7);
  const [emailAlerts, setEmailAlerts] = useState(true);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateBusinessProfile({
      name,
      category,
      location,
      email,
      currency,
    });
  };

  return (
    <div className="space-y-6 pb-12 max-w-4xl">
      {/* Title */}
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
          Business Settings
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Configure business details, notification thresholds, and currency preferences.
        </p>
      </div>

      {/* Business Profile Form */}
      <form onSubmit={handleSaveProfile} className="bg-white p-6 rounded-xl border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Store className="w-4 h-4 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900">Business Profile</h3>
          </div>
          <button
            type="submit"
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors shadow-sm shadow-blue-500/20"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Profile</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Business Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Business Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
            >
              <option value="Clothing & Fashion">Clothing & Fashion</option>
              <option value="Cosmetics">Cosmetics</option>
              <option value="Jewellery">Jewellery</option>
              <option value="Food">Food</option>
              <option value="Lifestyle">Lifestyle</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Operating Location / City</label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Owner Contact Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>
      </form>

      {/* Preferences & Thresholds */}
      <div className="bg-white p-6 rounded-xl border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
          <Bell className="w-4 h-4 text-blue-600" />
          <h3 className="text-sm font-bold text-slate-900">Decision Support Thresholds</h3>
        </div>

        <div className="space-y-4 text-xs">
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-semibold text-slate-700">Critical Stockout Alert Threshold</label>
              <span className="font-bold text-blue-700">{lowStockAlertDays} days remaining</span>
            </div>
            <input
              type="range"
              min="3"
              max="21"
              value={lowStockAlertDays}
              onChange={(e) => setLowStockAlertDays(parseInt(e.target.value, 10))}
              className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              Trigger high-risk notifications when a product has fewer than this many days of sales runway.
            </p>
          </div>

          <div className="pt-2 flex items-center justify-between">
            <div>
              <span className="font-semibold text-slate-800 block">Weekly Decision Summary Digest</span>
              <p className="text-[11px] text-slate-500">
                Receive weekly inventory restocking priorities and top buyer city trends.
              </p>
            </div>
            <input
              type="checkbox"
              checked={emailAlerts}
              onChange={(e) => setEmailAlerts(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Demo Controls & Account Danger Zone */}
      <div className="bg-white p-6 rounded-xl border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
          <Shield className="w-4 h-4 text-slate-600" />
          <h3 className="text-sm font-bold text-slate-900">Demo Management & Session</h3>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
          <div>
            <span className="font-bold text-slate-800 block">Urban Threads Demo Reset</span>
            <p className="text-[11px] text-slate-500">
              Restore the standard 1,248 order dataset with calibrated velocities.
            </p>
          </div>

          <button
            onClick={resetToDemoData}
            className="flex items-center justify-center gap-1.5 px-4 py-2 bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold rounded-lg border border-amber-200 transition-colors shadow-2xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Reset Demo Data</span>
          </button>
        </div>

        <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
          <div>
            <span className="font-bold text-slate-800 block">Sign Out</span>
            <p className="text-[11px] text-slate-500">End your current session and return to the home page.</p>
          </div>

          <button
            onClick={logout}
            className="flex items-center justify-center gap-1.5 px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-lg border border-rose-200 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Log Out</span>
          </button>
        </div>
      </div>
    </div>
  );
};
