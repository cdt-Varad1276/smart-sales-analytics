import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BusinessRecommendation } from '../../types';
import {
  Lightbulb,
  Boxes,
  TrendingUp,
  MapPin,
  Users,
  CheckCircle2,
  ArrowRight,
  Calculator,
  Eye,
  Filter,
} from 'lucide-react';

export const RecommendationsPage: React.FC = () => {
  const {
    recommendations,
    productMetrics,
    openProductDetail,
    openReorderCalculator,
    setCurrentPage,
    showToast,
  } = useApp();

  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('All');
  const [completedIds, setCompletedIds] = useState<Set<string>>(new Set());

  const toggleDone = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCompletedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
        showToast('Recommendation restored to active list.', 'info');
      } else {
        next.add(id);
        showToast('Recommendation marked as completed!', 'success');
      }
      return next;
    });
  };

  const handleAction = (rec: BusinessRecommendation) => {
    if (rec.targetProductId) {
      const prod = productMetrics.find((p) => p.productId === rec.targetProductId);
      if (prod) {
        if (rec.suggestedActionType === 'reorder') {
          openReorderCalculator(prod);
        } else {
          openProductDetail(prod);
        }
        return;
      }
    }

    if (rec.suggestedActionType === 'view_location') {
      setCurrentPage('sales-analytics');
      return;
    }

    setCurrentPage('products');
  };

  const filteredRecs = recommendations.filter((r) => {
    if (activeCategoryFilter === 'All') return true;
    return r.category === activeCategoryFilter;
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Inventory':
        return <Boxes className="w-4 h-4 text-amber-600" />;
      case 'Sales & Pricing':
        return <TrendingUp className="w-4 h-4 text-emerald-600" />;
      case 'Marketing & Geography':
        return <MapPin className="w-4 h-4 text-blue-600" />;
      default:
        return <Users className="w-4 h-4 text-purple-600" />;
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            What Should You Do Next?
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Actionable decision support generated directly from your sales velocities, inventory buffers, and buyer geography.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-600 bg-white px-3 py-1.5 rounded-lg border border-slate-200 shadow-2xs">
            {recommendations.length - completedIds.size} Active Decisions
          </span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        {['All', 'Inventory', 'Sales & Pricing', 'Marketing & Geography', 'Customer Retention'].map(
          (cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategoryFilter(cat)}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
                activeCategoryFilter === cat
                  ? 'bg-blue-600 text-white font-semibold shadow-2xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {cat}
            </button>
          )
        )}
      </div>

      {/* Recommendations Cards List */}
      <div className="space-y-4">
        {filteredRecs.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-xl border border-slate-200 text-xs text-slate-400">
            No recommendations under this category filter.
          </div>
        ) : (
          filteredRecs.map((rec) => {
            const isCompleted = completedIds.has(rec.id);

            return (
              <div
                key={rec.id}
                className={`bg-white rounded-xl border transition-all p-5 shadow-2xs flex flex-col justify-between ${
                  isCompleted
                    ? 'border-slate-200 bg-slate-50/60 opacity-60'
                    : 'border-slate-200/90 hover:border-blue-300'
                }`}
              >
                <div>
                  {/* Top Bar: Number, Category, Status */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-md bg-blue-50 text-blue-700 font-bold text-xs flex items-center justify-center border border-blue-200">
                        #{rec.number}
                      </span>
                      <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[11px] font-semibold border border-slate-200">
                        {getCategoryIcon(rec.category)}
                        <span>{rec.category}</span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => toggleDone(rec.id, e)}
                      className={`text-xs font-semibold px-2.5 py-1 rounded-lg border transition-colors flex items-center gap-1.5 ${
                        isCompleted
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <CheckCircle2 className={`w-3.5 h-3.5 ${isCompleted ? 'text-emerald-600' : 'text-slate-400'}`} />
                      <span>{isCompleted ? 'Done' : 'Mark as Done'}</span>
                    </button>
                  </div>

                  {/* Recommendation Title */}
                  <h3 className={`text-base font-bold ${isCompleted ? 'line-through text-slate-500' : 'text-slate-900'}`}>
                    {rec.title}
                  </h3>

                  {/* Structured Reason, Impact, Action Blocks */}
                  <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                    <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                      <span className="font-bold text-slate-700 block mb-1 text-[11px] uppercase tracking-wider">
                        Data Reason:
                      </span>
                      <p className="text-slate-600 leading-relaxed">{rec.reason}</p>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                      <span className="font-bold text-slate-700 block mb-1 text-[11px] uppercase tracking-wider">
                        Business Impact:
                      </span>
                      <p className="text-slate-600 leading-relaxed">{rec.impact}</p>
                    </div>

                    <div className="p-3 bg-blue-50/60 rounded-lg border border-blue-200/80">
                      <span className="font-bold text-blue-900 block mb-1 text-[11px] uppercase tracking-wider">
                        Recommended Action:
                      </span>
                      <p className="text-blue-950 font-medium leading-relaxed">{rec.action}</p>
                    </div>
                  </div>
                </div>

                {/* Footer Action Trigger */}
                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">
                    Decision Support grounded in verifiable records
                  </span>

                  <div className="flex items-center gap-2">
                    {rec.suggestedActionType === 'reorder' && (
                      <button
                        onClick={() => handleAction(rec)}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors shadow-sm shadow-blue-500/20"
                      >
                        <Calculator className="w-3.5 h-3.5" />
                        <span>Simulate Reorder Batch</span>
                      </button>
                    )}

                    {rec.suggestedActionType === 'view_product' && (
                      <button
                        onClick={() => handleAction(rec)}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold rounded-lg border border-slate-200 transition-colors shadow-2xs"
                      >
                        <Eye className="w-3.5 h-3.5 text-slate-500" />
                        <span>View Product Drilldown</span>
                      </button>
                    )}

                    {rec.suggestedActionType === 'view_location' && (
                      <button
                        onClick={() => handleAction(rec)}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors shadow-sm shadow-blue-500/20"
                      >
                        <MapPin className="w-3.5 h-3.5" />
                        <span>View Regional Sales Data</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
