import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { calculateRevenueTrends } from '../../utils/analyticsEngine';
import { formatINR, formatNumber } from '../../utils/formatters';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from 'recharts';

export const RevenueTrendChart: React.FC = () => {
  const { filteredOrders } = useApp();
  const [granularity, setGranularity] = useState<'daily' | 'weekly' | 'monthly'>('monthly');

  const trendData = calculateRevenueTrends(filteredOrders, granularity);

  return (
    <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Revenue Trend</h3>
          <p className="text-xs text-slate-500">Gross sales performance over time</p>
        </div>

        {/* Granularity Switcher */}
        <div className="flex items-center bg-slate-100 p-0.5 rounded-lg text-xs self-start sm:self-auto">
          <button
            onClick={() => setGranularity('daily')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all ${
              granularity === 'daily'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Daily
          </button>
          <button
            onClick={() => setGranularity('weekly')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all ${
              granularity === 'weekly'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Weekly
          </button>
          <button
            onClick={() => setGranularity('monthly')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all ${
              granularity === 'monthly'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Monthly
          </button>
        </div>
      </div>

      <div className="h-64 w-full">
        {trendData.length === 0 ? (
          <div className="h-full flex items-center justify-center text-xs text-slate-400">
            No sales records for selected filter.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563eb" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#2563eb" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis
                dataKey="dateLabel"
                tick={{ fontSize: 11, fill: '#64748b' }}
                stroke="#cbd5e1"
                tickLine={false}
              />
              <YAxis
                tick={{ fontSize: 11, fill: '#64748b' }}
                stroke="#cbd5e1"
                tickLine={false}
                tickFormatter={(val) => `₹${val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val}`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#ffffff',
                  borderColor: '#e2e8f0',
                  borderRadius: '10px',
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                  fontSize: '12px',
                }}
                formatter={(val: any) => [formatINR(val), 'Revenue']}
                labelFormatter={(label) => `Period: ${label}`}
              />
              <Area
                type="monotone"
                dataKey="revenue"
                stroke="#2563eb"
                strokeWidth={2.5}
                fillOpacity={1}
                fill="url(#revenueGrad)"
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
};
