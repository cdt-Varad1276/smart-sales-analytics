import React from 'react';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';
import { formatPercent } from '../../utils/formatters';

interface KpiCardProps {
  title: string;
  value: string;
  growth?: number;
  periodLabel?: string;
  icon?: React.ElementType;
  badge?: string;
  subtitle?: string;
}

export const KpiCard: React.FC<KpiCardProps> = ({
  title,
  value,
  growth,
  periodLabel = 'vs previous period',
  icon: Icon,
  badge,
  subtitle,
}) => {
  const isPositive = growth !== undefined && growth > 0;
  const isNegative = growth !== undefined && growth < 0;

  return (
    <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs hover:shadow-xs transition-shadow flex flex-col justify-between">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{title}</span>
        {Icon && (
          <div className="w-8 h-8 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-600">
            <Icon className="w-4 h-4" />
          </div>
        )}
      </div>

      <div className="mt-3">
        <h3 className="text-2xl font-bold text-slate-900 tracking-tight">{value}</h3>

        {growth !== undefined ? (
          <div className="flex items-center gap-1.5 mt-1.5 text-xs">
            <span
              className={`inline-flex items-center font-bold px-1.5 py-0.5 rounded text-[11px] ${
                isPositive
                  ? 'bg-emerald-50 text-emerald-700'
                  : isNegative
                  ? 'bg-rose-50 text-rose-700'
                  : 'bg-slate-100 text-slate-700'
              }`}
            >
              {isPositive && <ArrowUpRight className="w-3 h-3 mr-0.5" />}
              {isNegative && <ArrowDownRight className="w-3 h-3 mr-0.5" />}
              {!isPositive && !isNegative && <Minus className="w-3 h-3 mr-0.5" />}
              {formatPercent(growth)}
            </span>
            <span className="text-slate-400 text-[11px]">{periodLabel}</span>
          </div>
        ) : subtitle ? (
          <p className="text-[11px] text-slate-500 mt-1">{subtitle}</p>
        ) : null}
      </div>

      {badge && (
        <div className="mt-2 pt-2 border-t border-slate-100">
          <span className="text-[10px] font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
            {badge}
          </span>
        </div>
      )}
    </div>
  );
};
