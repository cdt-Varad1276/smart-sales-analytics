import React from 'react';
import { useApp } from '../../context/AppContext';
import { CheckCircle2, AlertTriangle, Info, AlertOctagon } from 'lucide-react';

export const Toast: React.FC = () => {
  const { toast } = useApp();

  if (!toast) return null;

  const getIcon = () => {
    switch (toast.type) {
      case 'success':
        return <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />;
      case 'error':
        return <AlertOctagon className="w-4 h-4 text-rose-600 shrink-0" />;
      default:
        return <Info className="w-4 h-4 text-blue-600 shrink-0" />;
    }
  };

  const getBorderColor = () => {
    switch (toast.type) {
      case 'success':
        return 'border-emerald-200 bg-white';
      case 'warning':
        return 'border-amber-200 bg-white';
      case 'error':
        return 'border-rose-200 bg-white';
      default:
        return 'border-blue-200 bg-white';
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom-4 fade-in duration-200 pointer-events-none">
      <div
        className={`flex items-center gap-3 px-4 py-3 rounded-xl border shadow-xl text-xs font-medium text-slate-800 pointer-events-auto max-w-sm ${getBorderColor()}`}
      >
        {getIcon()}
        <span>{toast.message}</span>
      </div>
    </div>
  );
};
