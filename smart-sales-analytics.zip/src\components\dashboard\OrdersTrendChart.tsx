import React from 'react';
import { useApp } from '../../context/AppContext';
import { calculateRevenueTrends } from '../../utils/analyticsEngine';
import { formatNumber } from '../../utils/formatters';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from 'recharts';

export const OrdersTrendChart: React.FC = () => {
  const { filteredOrders } = useApp();
  const trendData = calculateRevenueTrends(filteredOrders, 'monthly');

  return (
    <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Orders Volume Trend</h3>
          <p className="text-xs text-slate-500">Monthly completed order volume</p>
        </div>
      </div>

      <div className="h-64 w-full">
        {trendData.length === 0 ? (
          <div className="h-full flex items-center justify-center text-xs text-slate-400">
            No order volume data.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={trendData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis
                dataKey="dateLabel"
                tick={{ fontSize: 11, fill: '#64748b' }}
                stroke="#cbd5e1"
                tickLine={false}
              />
              <YAxis
                tick={{ fontSize: 11, fill: '#64748b' }}
                stroke="#cbd5e1"
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#ffffff',
                  borderColor: '#e2e8f0',
                  borderRadius: '10px',
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                  fontSize: '12px',
                }}
                formatter={(val: any) => [`${formatNumber(val)} orders`, 'Volume']}
                labelFormatter={(label) => `Month: ${label}`}
              />
              <Bar dataKey="orders" fill="#3b82f6" radius={[4, 4, 0, 0]} maxBarSize={40} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
};
