import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  TrendingUp,
  BarChart3,
  Boxes,
  Users,
  Lightbulb,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  FileSpreadsheet,
  Globe,
  ShoppingBag,
  ExternalLink,
  ChevronRight,
  Sparkles,
  Zap,
} from 'lucide-react';
import { formatINR } from '../../utils/formatters';

export const LandingPage: React.FC = () => {
  const { setCurrentPage, startDemoMode, openUploadModal, openIntegrationModal } = useApp();

  const sourceCards = [
    {
      name: 'Excel / CSV',
      type: 'Direct File Upload',
      status: 'Available Now',
      statusColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      description: 'Upload exported order sheets from any POS, spreadsheet, or offline ledger.',
      icon: FileSpreadsheet,
      action: openUploadModal,
      buttonText: 'Upload Data',
    },
    {
      name: 'IndiaMART',
      type: 'B2B Marketplace',
      status: 'Demo Integration',
      statusColor: 'bg-blue-50 text-blue-700 border-blue-200',
      description: 'Analyze buyer lead volume, conversions, and top inquiring regional cities.',
      icon: ShoppingBag,
      action: () =>
        openIntegrationModal({
          name: 'IndiaMART',
          status: 'Demo Integration',
          description:
            'IndiaMART Seller CRM sync parses buyer lead inquiries, quotation statuses, and confirmed dispatches to calculate category demand and regional lead velocity.',
        }),
      buttonText: 'Connect',
    },
    {
      name: 'Justdial',
      type: 'Local Search & Leads',
      status: 'Demo Integration',
      statusColor: 'bg-blue-50 text-blue-700 border-blue-200',
      description: 'Turn search inquiries and verified phone leads into predictable buyer trends.',
      icon: Globe,
      action: () =>
        openIntegrationModal({
          name: 'Justdial',
          status: 'Demo Integration',
          description:
            'Justdial Merchant sync integrates phone and WhatsApp inquiry logs to help local sellers identify peak seasonal inquiry periods.',
        }),
      buttonText: 'Connect',
    },
    {
      name: 'Your Website',
      type: 'Custom Cart / POS',
      status: 'Available via CSV',
      statusColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      description: 'Export transaction CSVs from custom portals or WhatsApp store order sheets.',
      icon: Globe,
      action: openUploadModal,
      buttonText: 'Upload CSV',
    },
    {
      name: 'Shopify',
      type: 'E-commerce Platform',
      status: 'Coming Soon',
      statusColor: 'bg-slate-100 text-slate-600 border-slate-200',
      description: 'Automated webhook sync for Shopify stores with real-time stockout alerts.',
      icon: ShoppingBag,
      action: () =>
        openIntegrationModal({
          name: 'Shopify',
          status: 'Coming Soon',
          description:
            'Direct Shopify OAuth app is currently in active development. Small sellers can currently export their Shopify Orders CSV and upload instantly into SmartSell.',
        }),
      buttonText: 'Join Waitlist',
    },
    {
      name: 'WooCommerce',
      type: 'WordPress Plugin',
      status: 'Coming Soon',
      statusColor: 'bg-slate-100 text-slate-600 border-slate-200',
      description: 'Plug-and-play REST API connection for self-hosted WordPress storefronts.',
      icon: Globe,
      action: () =>
        openIntegrationModal({
          name: 'WooCommerce',
          status: 'Coming Soon',
          description:
            'WooCommerce REST API token sync is planned for Q4. Use the Excel/CSV exporter to process WooCommerce data today.',
        }),
      buttonText: 'Join Waitlist',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Top Navigation */}
      <nav className="border-b border-slate-200 bg-white/90 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-sm shadow-blue-500/20">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-slate-900 tracking-tight text-base">SMARTSELL</span>
              <span className="text-[10px] font-semibold bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded border border-blue-200 uppercase tracking-wider">
                ANALYTICS
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentPage('login')}
              className="text-xs font-semibold text-slate-600 hover:text-slate-900 px-3 py-1.5 transition-colors"
            >
              Sign In
            </button>

            <button
              onClick={startDemoMode}
              className="flex items-center gap-1.5 text-xs font-bold text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-200 px-3 py-1.5 rounded-lg transition-colors shadow-2xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Try Demo Directly</span>
            </button>

            <button
              onClick={() => setCurrentPage('register')}
              className="flex items-center gap-1 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-1.5 rounded-lg shadow-sm shadow-blue-500/20 transition-all"
            >
              <span>Get Started</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-14 sm:py-20 px-6 max-w-6xl mx-auto w-full text-center">
        {/* Core Positioning Pill */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold mb-6 shadow-2xs">
          <Zap className="w-3.5 h-3.5" />
          <span>Decision Support & BI for Small Online Sellers</span>
        </div>

        {/* Hero Title */}
        <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight max-w-3xl mx-auto leading-[1.15]">
          Turn Your Sales Data Into <span className="text-blue-600">Better Business Decisions</span>
        </h1>

        {/* Subtitle */}
        <p className="mt-4 text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
          SmartSell Analytics helps small online businesses understand sales, customers, and inventory — and tells them what to do next.
        </p>

        {/* CTAs */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3.5">
          <button
            onClick={startDemoMode}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold rounded-xl shadow-md shadow-blue-600/20 transition-all group"
          >
            <span>Start Free Demo</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </button>

          <button
            onClick={() => {
              const el = document.getElementById('how-it-works');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="w-full sm:w-auto px-6 py-3 bg-white hover:bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl border border-slate-200 shadow-2xs transition-all"
          >
            See How It Works
          </button>
        </div>

        {/* Core Product Positioning Notice */}
        <div className="mt-8 max-w-2xl mx-auto p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs text-xs text-slate-600 text-center flex items-center justify-center gap-2">
          <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
          <span>
            <strong className="text-slate-800">We don’t replace where you sell.</strong> We sit on top of your existing sales data to help you forecast demand, prevent stockouts, and grow.
          </span>
        </div>

        {/* Realistic Dashboard Visual Preview Card */}
        <div className="mt-12 text-left bg-white rounded-2xl shadow-xl border border-slate-200/90 overflow-hidden max-w-4xl mx-auto ring-1 ring-slate-900/5">
          {/* Mock Window Top Bar */}
          <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs text-slate-500">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
              <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
              <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
              <span className="ml-2 font-mono text-[11px] text-slate-400">app.smartsellanalytics.com/dashboard</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-medium bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded">
                Live Demo Preview: Urban Threads
              </span>
            </div>
          </div>

          {/* Interactive Preview Body */}
          <div className="p-6 bg-slate-50/50 space-y-5">
            {/* Top row mini-KPIs */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs">
                <span className="text-[11px] text-slate-500 font-medium">Total Revenue</span>
                <span className="text-lg font-bold text-slate-900 block mt-0.5">₹8,42,500</span>
                <span className="text-[10px] font-semibold text-emerald-600">+12.4% vs last period</span>
              </div>

              <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs">
                <span className="text-[11px] text-slate-500 font-medium">Orders</span>
                <span className="text-lg font-bold text-slate-900 block mt-0.5">1,248</span>
                <span className="text-[10px] font-semibold text-emerald-600">+8.6% vs last period</span>
              </div>

              <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs">
                <span className="text-[11px] text-slate-500 font-medium">Average Order Value</span>
                <span className="text-lg font-bold text-slate-900 block mt-0.5">₹675</span>
                <span className="text-[10px] font-semibold text-emerald-600">+3.5% vs last period</span>
              </div>

              <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs">
                <span className="text-[11px] text-slate-500 font-medium">Repeat Customers</span>
                <span className="text-lg font-bold text-slate-900 block mt-0.5">32%</span>
                <span className="text-[10px] font-semibold text-slate-500">Healthy retention rate</span>
              </div>
            </div>

            {/* AI Insights Bar */}
            <div className="p-4 bg-blue-50/70 border border-blue-200 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Lightbulb className="w-4 h-4 text-blue-600" />
                  <span className="text-xs font-bold text-blue-900">3 Important Things We Found</span>
                </div>
                <span className="text-[10px] font-semibold bg-white text-blue-700 px-2 py-0.5 rounded border border-blue-200">
                  Automated Decision Engine
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                  <span className="font-semibold text-slate-900 block">Cotton Kurti +28%</span>
                  <p className="text-[11px] text-slate-500 mt-0.5">Stock running low (18 units, ~6 days left).</p>
                </div>
                <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                  <span className="font-semibold text-slate-900 block">Pune #1 Market</span>
                  <p className="text-[11px] text-slate-500 mt-0.5">42% of all order volume originates here.</p>
                </div>
                <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                  <span className="font-semibold text-slate-900 block">Inventory Review Needed</span>
                  <p className="text-[11px] text-slate-500 mt-0.5">7 items need restocking or price adjustments.</p>
                </div>
              </div>
            </div>

            <div className="text-center pt-2">
              <button
                onClick={startDemoMode}
                className="text-xs font-bold text-blue-600 hover:text-blue-800 inline-flex items-center gap-1 hover:underline"
              >
                <span>Click here to explore the full interactive dashboard live</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Data Connections Grid */}
      <section id="how-it-works" className="py-16 px-6 max-w-6xl mx-auto w-full border-t border-slate-200">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Connect the data you already have
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-2">
            Whether you sell on marketplaces, social media, your own shop, or offline invoices — SmartSell aggregates everything.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {sourceCards.map((src, i) => {
            const Icon = src.icon;
            return (
              <div
                key={i}
                className="p-5 bg-white rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-sm transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-9 h-9 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-700">
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${src.statusColor}`}>
                      {src.status}
                    </span>
                  </div>

                  <h3 className="font-bold text-sm text-slate-900">{src.name}</h3>
                  <span className="text-[11px] text-slate-400 block mb-2">{src.type}</span>
                  <p className="text-xs text-slate-600 leading-relaxed">{src.description}</p>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400 font-medium">Integration Mode</span>
                  <button
                    onClick={src.action}
                    className="flex items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    <span>{src.buttonText}</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Target Customers Strip */}
      <section className="py-12 bg-white border-y border-slate-200 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <span className="text-xs font-bold text-blue-700 uppercase tracking-wider block mb-2">
            Tailored For Modern Local & D2C Sellers
          </span>
          <p className="text-sm text-slate-600 max-w-xl mx-auto mb-6">
            Designed for non-technical business owners across India’s thriving retail & online commerce hubs.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-2.5">
            {[
              'Clothing & Fashion',
              'Cosmetics & Beauty',
              'Jewellery & Accessories',
              'Food & Beverage',
              'Lifestyle & Home',
              'Local Boutiques & Wholesalers',
            ].map((cat, idx) => (
              <span
                key={idx}
                className="px-3.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-700"
              >
                {cat}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto py-8 px-6 bg-slate-50 text-slate-500 border-t border-slate-200 text-xs">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">SMARTSELL ANALYTICS</span>
            <span>• Business Intelligence & Decision Support</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span>Prototype for Academic & Startup Evaluation</span>
            <span>Local Browser BI Processing</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
