import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { calculateDemandForecasts } from '../../utils/analyticsEngine';
import { formatINR, formatNumber } from '../../utils/formatters';
import {
  LineChart as LineChartIcon,
  TrendingUp,
  AlertCircle,
  HelpCircle,
  Calendar,
  Package,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
} from 'lucide-react';
import {
  ComposedChart,
  Line,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Legend,
} from 'recharts';

export const DemandForecastPage: React.FC = () => {
  const { filteredOrders, productMetrics, openReorderCalculator } = useApp();

  const [selectedProduct, setSelectedProduct] = useState<string>(
    productMetrics[0]?.productName || 'Cotton Kurti'
  );
  const [horizonDays, setHorizonDays] = useState<number>(30);

  const forecast = calculateDemandForecasts(filteredOrders, selectedProduct, horizonDays);
  const targetProductMetric = productMetrics.find((p) => p.productName === selectedProduct);

  // Combine historical and forecast for seamless composed chart visualization
  const chartData = [
    ...(forecast?.historicalSeries.map((h) => ({
      date: h.date,
      historical: h.units,
      forecast: null as number | null,
      lower: null as number | null,
      upper: null as number | null,
    })) || []),
    ...(forecast?.forecastSeries.map((f) => ({
      date: f.date,
      historical: null as number | null,
      forecast: f.units,
      lower: f.lower,
      upper: f.upper,
    })) || []),
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Title */}
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
          Demand Forecast & Sizing
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Estimated upcoming product demand based on moving averages and historical sales velocity.
        </p>
      </div>

      {/* Transparency Disclaimer Notice */}
      <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-xl flex items-start gap-2.5 text-xs text-blue-900">
        <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <strong className="font-bold text-blue-950">Estimation Methodology & Transparency:</strong>{' '}
          Forecasts are statistical projections computed using transparent moving averages and velocity trends. These are informed estimates to assist replenishment planning and are not guaranteed sales.
        </div>
      </div>

      {/* Controls Bar: Select Product & Select Horizon */}
      <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Product selector */}
        <div className="flex items-center gap-2 flex-1 max-w-md">
          <label className="text-xs font-semibold text-slate-700 whitespace-nowrap">
            Select Product:
          </label>
          <select
            value={selectedProduct}
            onChange={(e) => setSelectedProduct(e.target.value)}
            className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
          >
            {productMetrics.map((p) => (
              <option key={p.productId} value={p.productName}>
                {p.productName} ({p.category})
              </option>
            ))}
          </select>
        </div>

        {/* Horizon selector: 7, 30, 60, 90 */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-700">Forecast Horizon:</span>
          <div className="flex items-center bg-slate-100 p-0.5 rounded-lg text-xs">
            {[7, 30, 60, 90].map((days) => (
              <button
                key={days}
                onClick={() => setHorizonDays(days)}
                className={`px-3 py-1 rounded-md font-medium transition-all ${
                  horizonDays === days
                    ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {days} days
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Forecast Metric Cards */}
      {forecast ? (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
              <span className="text-[11px] font-semibold text-slate-500 uppercase block">
                Historical Monthly Average
              </span>
              <span className="text-xl font-bold text-slate-900 block mt-1">
                {forecast.historicalMonthlyAvg} units
              </span>
              <span className="text-[11px] text-slate-400">
                ~{forecast.historicalDailyAvg} units / day
              </span>
            </div>

            <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
              <span className="text-[11px] font-semibold text-slate-500 uppercase block">
                Projected {horizonDays}-Day Demand
              </span>
              <span className="text-xl font-bold text-blue-600 block mt-1">
                {forecast.forecastUnits} units
              </span>
              <span className="text-[11px] text-slate-500">
                Range: {forecast.confidenceInterval.min}–{forecast.confidenceInterval.max} units
              </span>
            </div>

            <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
              <span className="text-[11px] font-semibold text-slate-500 uppercase block">
                Projected Sales Revenue
              </span>
              <span className="text-xl font-bold text-slate-900 block mt-1">
                {formatINR(forecast.projectedRevenue)}
              </span>
              <span className="text-[11px] text-emerald-600 font-semibold">
                Est. gross incoming
              </span>
            </div>

            <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
              <span className="text-[11px] font-semibold text-slate-500 uppercase block">
                Velocity Trajectory
              </span>
              <span className={`inline-flex items-center text-sm font-bold mt-1 px-2 py-0.5 rounded-full border ${
                forecast.trend === 'Increasing'
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                  : forecast.trend === 'Softening'
                  ? 'bg-rose-50 text-rose-700 border-rose-200'
                  : 'bg-slate-100 text-slate-700 border-slate-200'
              }`}>
                {forecast.trend} ({forecast.trendPercentage > 0 ? '+' : ''}{forecast.trendPercentage}%)
              </span>
              <span className="text-[11px] text-slate-400 block mt-1">
                Moving average delta
              </span>
            </div>
          </div>

          {/* Forecast Chart */}
          <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Demand Projection Curve ({selectedProduct})
                </h3>
                <p className="text-xs text-slate-500">
                  Solid blue indicates historical orders; dashed blue indicates upcoming projection with uncertainty band.
                </p>
              </div>

              <div className="flex items-center gap-4 text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 bg-blue-600 inline-block" />
                  <span className="text-slate-600">Historical Units</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 bg-indigo-600 border-t border-dashed inline-block" />
                  <span className="text-slate-600">Forecast</span>
                </div>
              </div>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#64748b' }} stroke="#cbd5e1" />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} stroke="#cbd5e1" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '8px', fontSize: '11px' }}
                    formatter={(val: any, name: any) => [`${val} units`, name === 'historical' ? 'Historical' : 'Forecast']}
                  />
                  <Line
                    type="monotone"
                    dataKey="historical"
                    stroke="#2563eb"
                    strokeWidth={2}
                    dot={{ r: 2 }}
                    connectNulls={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="forecast"
                    stroke="#4f46e5"
                    strokeWidth={2}
                    strokeDasharray="4 4"
                    dot={{ r: 3, fill: '#4f46e5' }}
                    connectNulls={false}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Business Implication & Action Plan Box */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                <Lightbulb className="w-4 h-4 text-blue-600" />
                <span>Business Implication</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                {forecast.businessImplication}
              </p>

              {forecast.stockoutRiskDate && (
                <div className="p-2.5 bg-rose-50 rounded-lg border border-rose-200 text-xs text-rose-800 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>
                    Estimated stockout date if unreplenished:{' '}
                    <strong>{forecast.stockoutRiskDate}</strong>
                  </span>
                </div>
              )}
            </div>

            <div className="p-5 bg-blue-50/50 rounded-xl border border-blue-200 space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-xs font-bold text-blue-900">
                  <CheckCircle2 className="w-4 h-4 text-blue-600" />
                  <span>Decision Support Recommendation</span>
                </div>
                <p className="text-xs text-blue-950 font-medium leading-relaxed mt-2">
                  {forecast.recommendedAction}
                </p>
              </div>

              {targetProductMetric && targetProductMetric.currentStock !== null && (
                <div className="pt-2">
                  <button
                    onClick={() => openReorderCalculator(targetProductMetric)}
                    className="w-full py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg transition-colors shadow-sm shadow-blue-500/20"
                  >
                    Calculate Reorder Quantity for {selectedProduct}
                  </button>
                </div>
              )}
            </div>
          </div>
        </>
      ) : (
        <div className="p-12 text-center bg-white rounded-xl border border-slate-200 text-xs text-slate-400">
          Not enough historical orders to generate forecast for {selectedProduct}.
        </div>
      )}
    </div>
  );
};
