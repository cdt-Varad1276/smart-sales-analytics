import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { parseCsvFile, CsvValidationReport } from '../../utils/csvParser';
import { downloadSampleCsv } from '../../data/sampleCsv';
import { Order } from '../../types';
import {
  X,
  UploadCloud,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  Download,
  Loader2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Check,
} from 'lucide-react';

export const CsvUploadModal: React.FC = () => {
  const { isUploadModalOpen, closeUploadModal, loadUploadedOrders, setCurrentPage, startDemoMode } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [parseReport, setParseReport] = useState<CsvValidationReport | null>(null);
  const [parsedOrders, setParsedOrders] = useState<Order[] | null>(null);
  const [parseError, setParseError] = useState<string | null>(null);

  // Animated processing checklist state
  const [isProcessingAnimation, setIsProcessingAnimation] = useState(false);
  const [processingStep, setProcessingStep] = useState<number>(0);

  if (!isUploadModalOpen) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    setIsParsing(true);
    setParseError(null);
    setParseReport(null);
    setParsedOrders(null);

    try {
      const result = await parseCsvFile(file);
      setParsedOrders(result.orders);
      setParseReport(result.report);
    } catch (err: any) {
      setParseError(err.message || 'Failed to parse CSV file. Ensure valid CSV formatting.');
    } finally {
      setIsParsing(false);
    }
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    setIsParsing(true);
    setParseError(null);
    setParseReport(null);
    setParsedOrders(null);

    try {
      const result = await parseCsvFile(file);
      setParsedOrders(result.orders);
      setParseReport(result.report);
    } catch (err: any) {
      setParseError(err.message || 'Failed to parse CSV file.');
    } finally {
      setIsParsing(false);
    }
  };

  const handleConfirmImport = () => {
    if (!parsedOrders || !parsedOrders.length) return;

    setIsProcessingAnimation(true);
    setProcessingStep(1);

    // Step 1: Orders processed
    setTimeout(() => {
      setProcessingStep(2); // Products identified
    }, 600);

    // Step 2: Customers identified
    setTimeout(() => {
      setProcessingStep(3); // Customers identified
    }, 1200);

    // Step 3: Sales trends calculated
    setTimeout(() => {
      setProcessingStep(4); // Trends calculated
    }, 1800);

    // Complete & redirect
    setTimeout(() => {
      setIsProcessingAnimation(false);
      loadUploadedOrders(parsedOrders, selectedFile?.name || 'Custom Uploaded CSV');
      closeUploadModal();
      setCurrentPage('dashboard');
    }, 2400);
  };

  const resetState = () => {
    setSelectedFile(null);
    setParseReport(null);
    setParsedOrders(null);
    setParseError(null);
    setIsProcessingAnimation(false);
    setProcessingStep(0);
    closeUploadModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div>
            <h3 className="text-base font-bold text-slate-900">Upload Sales & Inventory CSV</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Import orders from your website, POS, or offline spreadsheets
            </p>
          </div>
          <button
            onClick={resetState}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* Processing Animation Screen */}
          {isProcessingAnimation ? (
            <div className="py-8 px-4 flex flex-col items-center justify-center text-center space-y-6">
              <div className="w-14 h-14 rounded-full bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 animate-pulse">
                <Loader2 className="w-7 h-7 animate-spin" />
              </div>

              <div>
                <h4 className="text-base font-bold text-slate-900">
                  Analyzing your business data...
                </h4>
                <p className="text-xs text-slate-500 mt-1">
                  Computing sales velocities, customer frequency, and demand forecasts
                </p>
              </div>

              {/* Checklist */}
              <div className="w-full max-w-sm space-y-3 text-left bg-slate-50 border border-slate-200 p-4 rounded-xl">
                <div className={`flex items-center gap-2.5 text-xs font-medium transition-colors ${
                  processingStep >= 1 ? 'text-emerald-700' : 'text-slate-400'
                }`}>
                  {processingStep >= 1 ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-300" />
                  )}
                  <span>Orders processed & validated</span>
                </div>

                <div className={`flex items-center gap-2.5 text-xs font-medium transition-colors ${
                  processingStep >= 2 ? 'text-emerald-700' : 'text-slate-400'
                }`}>
                  {processingStep >= 2 ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-300" />
                  )}
                  <span>Products & categories indexed</span>
                </div>

                <div className={`flex items-center gap-2.5 text-xs font-medium transition-colors ${
                  processingStep >= 3 ? 'text-emerald-700' : 'text-slate-400'
                }`}>
                  {processingStep >= 3 ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-300" />
                  )}
                  <span>Customer cohorts & repeat rates calculated</span>
                </div>

                <div className={`flex items-center gap-2.5 text-xs font-medium transition-colors ${
                  processingStep >= 4 ? 'text-emerald-700' : 'text-slate-400'
                }`}>
                  {processingStep >= 4 ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-300" />
                  )}
                  <span>Sales velocity & demand forecasts generated</span>
                </div>
              </div>
            </div>
          ) : (
            <>
              {/* Dropzone */}
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
                  selectedFile
                    ? 'border-blue-400 bg-blue-50/30'
                    : 'border-slate-300 hover:border-blue-500 hover:bg-slate-50'
                }`}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept=".csv,text/csv"
                  className="hidden"
                />

                <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-3 border border-blue-100">
                  <UploadCloud className="w-6 h-6" />
                </div>

                <p className="text-sm font-semibold text-slate-800">
                  {selectedFile ? selectedFile.name : 'Click to select CSV or drag & drop'}
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Supported format: .csv (order_id, date, product_name, quantity, unit_price...)
                </p>

                {selectedFile && (
                  <span className="inline-block mt-2 text-[11px] font-medium text-slate-600 bg-white px-2 py-0.5 rounded border border-slate-200">
                    {(selectedFile.size / 1024).toFixed(1)} KB
                  </span>
                )}
              </div>

              {/* Parsing Indicator */}
              {isParsing && (
                <div className="flex items-center justify-center gap-2 py-3 text-xs text-slate-600">
                  <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                  <span>Validating CSV structure...</span>
                </div>
              )}

              {/* Parse Error */}
              {parseError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <span>{parseError}</span>
                </div>
              )}

              {/* Validation Review Panel */}
              {parseReport && (
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-200">
                    <span className="font-semibold text-slate-800">Validation Breakdown</span>
                    <span className="font-mono text-emerald-700 font-semibold">
                      {parseReport.validRowsCount} valid rows detected
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                      <span className="text-slate-500 block text-[11px]">Total Rows</span>
                      <span className="font-bold text-slate-900 text-sm">
                        {parseReport.totalRowsDetected}
                      </span>
                    </div>

                    <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                      <span className="text-slate-500 block text-[11px]">Stock Column</span>
                      <span className={`font-semibold text-xs flex items-center gap-1 ${
                        parseReport.hasStockColumn ? 'text-emerald-700' : 'text-amber-700'
                      }`}>
                        {parseReport.hasStockColumn ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                            Detected
                          </>
                        ) : (
                          <>
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                            Not Provided
                          </>
                        )}
                      </span>
                    </div>
                  </div>

                  {/* Warnings if any */}
                  {parseReport.warnings.length > 0 && (
                    <div className="space-y-1.5 pt-1">
                      {parseReport.warnings.map((warn, i) => (
                        <div key={i} className="flex items-start gap-2 text-[11px] text-amber-800 bg-amber-50/70 p-2 rounded border border-amber-200/50">
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                          <span>{warn}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Sample Template & Demo Data Options */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 text-xs">
                <button
                  type="button"
                  onClick={downloadSampleCsv}
                  className="flex items-center gap-1.5 text-blue-600 hover:text-blue-800 font-medium hover:underline"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Sample CSV Template</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    startDemoMode();
                    closeUploadModal();
                  }}
                  className="flex items-center gap-1.5 text-amber-700 hover:text-amber-900 font-medium bg-amber-50 hover:bg-amber-100 px-2.5 py-1 rounded-md border border-amber-200 transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  <span>Use Demo Business Data</span>
                </button>
              </div>

              {/* Security note */}
              <div className="flex items-center gap-2 text-[11px] text-slate-400 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                <ShieldCheck className="w-4 h-4 text-slate-400 shrink-0" />
                <span>
                  Your business data is parsed locally in your browser. No third-party data collection.
                </span>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        {!isProcessingAnimation && (
          <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
            <button
              onClick={resetState}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
            >
              Cancel
            </button>

            <button
              onClick={handleConfirmImport}
              disabled={!parsedOrders || parsedOrders.length === 0}
              className={`flex items-center gap-2 px-5 py-2 rounded-lg text-xs font-bold transition-all shadow-sm ${
                parsedOrders && parsedOrders.length > 0
                  ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/20'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <span>Import & Analyze Data</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
