import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/layout/Sidebar';
import { Topbar } from './components/layout/Topbar';
import { LandingPage } from './components/landing/LandingPage';
import { LoginPage } from './components/auth/LoginPage';
import { BusinessSetupPage } from './components/auth/BusinessSetupPage';
import { DataConnectionPage } from './components/pages/DataConnectionPage';
import { MainDashboardPage } from './components/pages/MainDashboardPage';
import { SalesAnalyticsPage } from './components/pages/SalesAnalyticsPage';
import { ProductPerformancePage } from './components/pages/ProductPerformancePage';
import { CustomerAnalyticsPage } from './components/pages/CustomerAnalyticsPage';
import { InventoryPage } from './components/pages/InventoryPage';
import { DemandForecastPage } from './components/pages/DemandForecastPage';
import { RecommendationsPage } from './components/pages/RecommendationsPage';
import { DataSourcesPage } from './components/pages/DataSourcesPage';
import { SettingsPage } from './components/pages/SettingsPage';

// Modals
import { CsvUploadModal } from './components/modals/CsvUploadModal';
import { IntegrationModal } from './components/modals/IntegrationModal';
import { ProductDetailModal } from './components/modals/ProductDetailModal';
import { ReorderCalculatorModal } from './components/modals/ReorderCalculatorModal';
import { ExportReportModal } from './components/modals/ExportReportModal';
import { Toast } from './components/modals/Toast';

const AppContent: React.FC = () => {
  const { currentPage } = useApp();

  // Standalone pages outside the main dashboard shell
  if (currentPage === 'landing') {
    return (
      <>
        <LandingPage />
        <CsvUploadModal />
        <IntegrationModal />
        <Toast />
      </>
    );
  }

  if (currentPage === 'login' || currentPage === 'register') {
    return (
      <>
        <LoginPage />
        <Toast />
      </>
    );
  }

  if (currentPage === 'business-setup') {
    return (
      <>
        <BusinessSetupPage />
        <Toast />
      </>
    );
  }

  if (currentPage === 'connect-data') {
    return (
      <>
        <DataConnectionPage />
        <CsvUploadModal />
        <IntegrationModal />
        <Toast />
      </>
    );
  }

  // Core App Shell for authenticated / demo BI exploration
  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <MainDashboardPage />;
      case 'sales-analytics':
        return <SalesAnalyticsPage />;
      case 'products':
        return <ProductPerformancePage />;
      case 'customers':
        return <CustomerAnalyticsPage />;
      case 'inventory':
        return <InventoryPage />;
      case 'forecast':
        return <DemandForecastPage />;
      case 'recommendations':
        return <RecommendationsPage />;
      case 'data-sources':
        return <DataSourcesPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <MainDashboardPage />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50 font-sans">
      {/* Sidebar Navigation */}
      <Sidebar />

      {/* Main Content Pane */}
      <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        <Topbar />
        <main className="flex-1 p-6 sm:p-8 max-w-7xl w-full mx-auto">
          {renderCurrentPage()}
        </main>
      </div>

      {/* Global Modals & Notifications */}
      <CsvUploadModal />
      <IntegrationModal />
      <ProductDetailModal />
      <ReorderCalculatorModal />
      <ExportReportModal />
      <Toast />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;
