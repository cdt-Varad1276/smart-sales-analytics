import React from 'react';
import { useApp } from '../../context/AppContext';
import { formatINR, formatNumber } from '../../utils/formatters';
import { KpiCard } from '../dashboard/KpiCard';
import { InsightsPanel } from '../dashboard/InsightsPanel';
import { RevenueTrendChart } from '../dashboard/RevenueTrendChart';
import { OrdersTrendChart } from '../dashboard/OrdersTrendChart';
import { CategoryDonutChart } from '../dashboard/CategoryDonutChart';
import { TopProductsBarChart } from '../dashboard/TopProductsBarChart';
import { LocationDistributionTable } from '../dashboard/LocationDistributionTable';
import { RecentOrdersTable } from '../dashboard/RecentOrdersTable';
import {
  Wallet,
  ShoppingBag,
  CircleDollarSign,
  UserCheck,
  TrendingUp,
  Download,
  UploadCloud,
  Boxes,
  Sparkles,
  ArrowRight,
} from 'lucide-react';

export const MainDashboardPage: React.FC = () => {
  const {
    businessProfile,
    overviewMetrics,
    openUploadModal,
    openExportReportModal,
    setCurrentPage,
    dateRange,
  } = useApp();

  // Dynamic greeting based on time of day
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  const dateRangeLabel =
    dateRange === '30d'
      ? 'Last 30 Days'
      : dateRange === '90d'
      ? 'Last 90 Days'
      : dateRange === 'year'
      ? 'This Year'
      : 'All Time';

  return (
    <div className="space-y-6 pb-12">
      {/* Title & Context Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
              {greeting}, {businessProfile.name}
            </h1>
            {businessProfile.isDemoData && (
              <span className="text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-600" />
                Demo Dataset
              </span>
            )}
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Here's what is happening with your sales, inventory, and customer demand ({dateRangeLabel}).
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={openUploadModal}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-sm shadow-blue-500/20 transition-all"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Upload New CSV</span>
          </button>

          <button
            onClick={openExportReportModal}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-lg border border-slate-200 shadow-2xs transition-colors"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Export Report</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          title="Total Revenue"
          value={formatINR(overviewMetrics.totalRevenue)}
          growth={overviewMetrics.revenueGrowth}
          icon={Wallet}
        />
        <KpiCard
          title="Orders"
          value={formatNumber(overviewMetrics.totalOrders)}
          growth={overviewMetrics.ordersGrowth}
          icon={ShoppingBag}
        />
        <KpiCard
          title="Average Order Value"
          value={formatINR(overviewMetrics.averageOrderValue)}
          growth={overviewMetrics.aovGrowth}
          icon={CircleDollarSign}
        />
        <KpiCard
          title="Repeat Customers"
          value={`${overviewMetrics.repeatCustomerPercentage.toFixed(0)}%`}
          growth={overviewMetrics.repeatGrowth}
          icon={UserCheck}
          badge={`${overviewMetrics.repeatCustomersCount} loyal buyers`}
        />
      </div>

      {/* AI / Business Insights Section ("3 Important Things We Found") */}
      <InsightsPanel />

      {/* Primary Trend Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <RevenueTrendChart />
        <OrdersTrendChart />
      </div>

      {/* Middle Grid: Category Breakdown + Top Products */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <CategoryDonutChart />
        <TopProductsBarChart />
      </div>

      {/* Bottom Grid: Orders by Location + Recent Orders */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <LocationDistributionTable />
        <RecentOrdersTable />
      </div>

      {/* Recommendation Prompt Callout */}
      <div className="p-5 bg-gradient-to-r from-blue-900 to-indigo-950 text-white rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-md">
        <div className="space-y-1 text-center sm:text-left">
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-300">
            Actionable Next Steps
          </span>
          <h3 className="text-base font-bold text-white">
            Ready to review supplier reorders and marketing allocation?
          </h3>
          <p className="text-xs text-blue-200">
            SmartSell has generated custom priority recommendations based on your current sales momentum and stock levels.
          </p>
        </div>

        <button
          onClick={() => setCurrentPage('recommendations')}
          className="px-5 py-2.5 bg-white hover:bg-blue-50 text-blue-950 text-xs font-bold rounded-xl shadow transition-colors whitespace-nowrap flex items-center gap-1.5"
        >
          <span>See What To Do Next</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
