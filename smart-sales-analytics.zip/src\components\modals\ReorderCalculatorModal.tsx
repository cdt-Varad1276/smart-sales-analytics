import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatINR } from '../../utils/formatters';
import { X, Calculator, Boxes, ShieldAlert, CheckCircle2, ArrowRight } from 'lucide-react';

export const ReorderCalculatorModal: React.FC = () => {
  const { selectedProductForReorder, closeReorderCalculator, showToast } = useApp();

  const [leadTimeDays, setLeadTimeDays] = useState<number>(10);
  const [safetyBufferDays, setSafetyBufferDays] = useState<number>(7);

  if (!selectedProductForReorder) return null;

  const product = selectedProductForReorder;
  const currentStock = product.currentStock ?? 0;
  const velocity = Math.max(0.1, product.velocity);

  // Calculations
  const leadTimeDemand = Math.ceil(velocity * leadTimeDays);
  const safetyStock = Math.ceil(velocity * safetyBufferDays);
  const reorderPoint = leadTimeDemand + safetyStock;

  // Recommended order quantity to cover replenishment cycle
  const cycleDays = 30; // standard 30 day batch
  const cycleDemand = Math.ceil(velocity * cycleDays);
  const suggestedReorderUnits = Math.max(15, cycleDemand + safetyStock - currentStock);
  const estimatedWholesaleCost = Math.round(suggestedReorderUnits * (product.averagePrice * 0.55)); // est 55% COGS

  const handleSimulateReorder = () => {
    showToast(
      `Reorder plan created: ${suggestedReorderUnits} units of ${product.productName} (Est. cost ${formatINR(estimatedWholesaleCost)})`,
      'success'
    );
    closeReorderCalculator();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600">
              <Calculator className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Inventory Reorder Calculator</h3>
              <p className="text-xs text-slate-500">Calculate optimal replenishment for {product.productName}</p>
            </div>
          </div>
          <button
            onClick={closeReorderCalculator}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Velocity & Stock Summary */}
          <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-200">
            <div>
              <span className="text-slate-500 block">Sales Velocity</span>
              <span className="font-bold text-slate-900 text-sm">{velocity} units / day</span>
            </div>
            <div>
              <span className="text-slate-500 block">Current In-Stock</span>
              <span className={`font-bold text-sm ${currentStock <= 15 ? 'text-rose-600' : 'text-slate-900'}`}>
                {currentStock} units ({product.daysRemaining ?? 0} days left)
              </span>
            </div>
          </div>

          {/* User Parameters */}
          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <label className="font-semibold text-slate-700">Supplier Lead Time (Days)</label>
                <span className="font-bold text-blue-700">{leadTimeDays} days</span>
              </div>
              <input
                type="range"
                min="2"
                max="30"
                value={leadTimeDays}
                onChange={(e) => setLeadTimeDays(parseInt(e.target.value, 10))}
                className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <span className="text-[11px] text-slate-400">Time taken from placing order with manufacturer until arrival.</span>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <label className="font-semibold text-slate-700">Safety Buffer Stock (Days)</label>
                <span className="font-bold text-blue-700">{safetyBufferDays} days</span>
              </div>
              <input
                type="range"
                min="3"
                max="21"
                value={safetyBufferDays}
                onChange={(e) => setSafetyBufferDays(parseInt(e.target.value, 10))}
                className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <span className="text-[11px] text-slate-400">Extra buffer days to absorb unexpected demand surges.</span>
            </div>
          </div>

          {/* Results Card */}
          <div className="p-4 bg-blue-50/70 border border-blue-200 rounded-xl space-y-3">
            <span className="text-xs font-bold text-blue-900 uppercase tracking-wide block">
              Optimal Reorder Recommendation
            </span>

            <div className="flex items-baseline justify-between">
              <span className="text-sm font-semibold text-slate-800">Suggested Order Units:</span>
              <span className="text-2xl font-bold text-blue-700">{suggestedReorderUnits} units</span>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-blue-200/60 text-xs">
              <div>
                <span className="text-slate-500 block text-[11px]">Reorder Point (ROP):</span>
                <span className="font-semibold text-slate-800">{reorderPoint} units</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">Est. Wholesale Cost:</span>
                <span className="font-semibold text-slate-800">{formatINR(estimatedWholesaleCost)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={closeReorderCalculator}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
          >
            Cancel
          </button>

          <button
            onClick={handleSimulateReorder}
            className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors shadow-sm shadow-blue-500/20"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Confirm Reorder Plan</span>
          </button>
        </div>
      </div>
    </div>
  );
};
