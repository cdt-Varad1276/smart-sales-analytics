import React from 'react';
import { useApp } from '../../context/AppContext';
import { formatINR, formatNumber } from '../../utils/formatters';
import { MapPin, ArrowRight } from 'lucide-react';

export const LocationDistributionTable: React.FC = () => {
  const { cityMetrics, setCurrentPage } = useApp();

  return (
    <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
            <MapPin className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">Orders by Location</h3>
            <p className="text-xs text-slate-500">Regional sales concentration & delivery markets</p>
          </div>
        </div>

        <button
          onClick={() => setCurrentPage('sales-analytics')}
          className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 hover:underline"
        >
          <span>Deep-dive</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600">
            <tr>
              <th className="py-2.5 px-3">City / Market</th>
              <th className="py-2.5 px-3 text-right">Orders</th>
              <th className="py-2.5 px-3 text-right">Revenue</th>
              <th className="py-2.5 px-3 text-right">Share</th>
              <th className="py-2.5 px-3">Top Product</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {cityMetrics.slice(0, 6).map((item, idx) => (
              <tr key={item.city || idx} className="hover:bg-slate-50/80 transition-colors">
                <td className="py-2.5 px-3">
                  <div className="flex items-center gap-1.5">
                    <span className="font-semibold text-slate-900">{item.city}</span>
                    <span className="text-[10px] text-slate-400 font-normal">({item.state})</span>
                    {idx === 0 && (
                      <span className="text-[9px] font-bold bg-blue-50 text-blue-700 px-1 py-0.2 rounded border border-blue-200 uppercase">
                        Top
                      </span>
                    )}
                  </div>
                </td>
                <td className="py-2.5 px-3 text-right font-medium text-slate-700">
                  {formatNumber(item.orderCount)}
                </td>
                <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                  {formatINR(item.revenue)}
                </td>
                <td className="py-2.5 px-3 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <div className="w-12 h-1.5 bg-slate-100 rounded-full overflow-hidden hidden sm:block">
                      <div
                        className="h-full bg-blue-600 rounded-full"
                        style={{ width: `${item.percentageOfRevenue}%` }}
                      />
                    </div>
                    <span className="font-medium text-slate-600 w-8 text-right">
                      {item.percentageOfRevenue.toFixed(0)}%
                    </span>
                  </div>
                </td>
                <td className="py-2.5 px-3 text-slate-600 font-medium truncate max-w-[130px]">
                  {item.topProduct}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
