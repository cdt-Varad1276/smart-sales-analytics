import React from 'react';
import { useApp } from '../../context/AppContext';
import { formatNumber } from '../../utils/formatters';
import { ProductMetric } from '../../types';
import {
  Boxes,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Calculator,
  ArrowRight,
  ShieldCheck,
  TrendingUp,
  Package,
} from 'lucide-react';

export const InventoryPage: React.FC = () => {
  const { productMetrics, openProductDetail, openReorderCalculator, openUploadModal } = useApp();

  const hasStockData = productMetrics.some((p) => p.currentStock !== null);

  const highRiskProducts = productMetrics.filter(
    (p) => p.status === 'High Risk' || (p.daysRemaining !== null && p.daysRemaining <= 7)
  );

  const mediumRiskProducts = productMetrics.filter(
    (p) => p.daysRemaining !== null && p.daysRemaining > 7 && p.daysRemaining <= 21
  );

  const healthyProducts = productMetrics.filter(
    (p) => p.daysRemaining !== null && p.daysRemaining > 21
  );

  // 7 products need inventory review / monitoring banner
  const attentionCount = highRiskProducts.length + mediumRiskProducts.length;

  const getRiskBadge = (daysRemaining: number | null, status: ProductMetric['status']) => {
    if (daysRemaining === null) {
      return (
        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
          No Stock Data
        </span>
      );
    }
    if (daysRemaining <= 7) {
      return (
        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-rose-50 text-rose-700 border border-rose-200 flex items-center gap-1 w-max">
          <AlertTriangle className="w-3 h-3 text-rose-600" />
          High Risk
        </span>
      );
    }
    if (daysRemaining <= 21) {
      return (
        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 flex items-center gap-1 w-max">
          <Clock className="w-3 h-3 text-amber-600" />
          Medium Risk
        </span>
      );
    }
    return (
      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1 w-max">
        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
        Healthy
      </span>
    );
  };

  const getVelocityBadge = (velocity: number) => {
    if (velocity >= 2.5) {
      return <span className="font-semibold text-rose-700">High ({velocity} / day)</span>;
    }
    if (velocity >= 1.0) {
      return <span className="font-semibold text-amber-700">Medium ({velocity} / day)</span>;
    }
    return <span className="font-medium text-slate-600">Moderate ({velocity} / day)</span>;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Title */}
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
          Inventory Intelligence
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Stock depletion runways, replenishment thresholds, and automated stockout risk alerts.
        </p>
      </div>

      {/* Critical Attention Banner */}
      {hasStockData ? (
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-amber-950 shadow-2xs">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-amber-100/90 text-amber-800 shrink-0">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-amber-950 uppercase tracking-wide">
                Inventory Attention Alert
              </h3>
              <p className="text-xs text-amber-900/90 mt-0.5">
                <strong className="font-bold text-amber-950">{attentionCount} products</strong> require inventory review due to rapid sales velocity or low days of buffer stock.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold bg-white text-amber-900 px-3 py-1.5 rounded-lg border border-amber-200">
              {highRiskProducts.length} Critical Stockout Risks
            </span>
          </div>
        </div>
      ) : (
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
            <span>
              This insight requires inventory data. Upload a CSV with the <code className="bg-slate-200 px-1 py-0.5 rounded text-slate-800">stock_available</code> column to unlock automated stockout predictions.
            </span>
          </div>
          <button
            onClick={openUploadModal}
            className="px-3 py-1.5 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
          >
            Upload Inventory CSV
          </button>
        </div>
      )}

      {/* Status Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-semibold uppercase">High Stockout Risk</span>
            <AlertTriangle className="w-4 h-4 text-rose-500" />
          </div>
          <span className="text-2xl font-bold text-rose-600 block mt-1">
            {highRiskProducts.length} Products
          </span>
          <span className="text-[11px] text-slate-500">Stock runway ≤ 7 days</span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-semibold uppercase">Medium Risk / Monitor</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <span className="text-2xl font-bold text-amber-700 block mt-1">
            {mediumRiskProducts.length} Products
          </span>
          <span className="text-[11px] text-slate-500">Stock runway 8–21 days</span>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-semibold uppercase">Healthy Buffer</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <span className="text-2xl font-bold text-emerald-700 block mt-1">
            {healthyProducts.length} Products
          </span>
          <span className="text-[11px] text-slate-500">Stock runway &gt; 21 days</span>
        </div>
      </div>

      {/* Main Inventory Intelligence Table */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-2xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div>
            <h3 className="text-sm font-bold text-slate-900">SKU Depletion & Reorder Status</h3>
            <p className="text-xs text-slate-500">
              Runway calculated dynamically: (Current Stock ÷ Daily Sales Velocity)
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600">
              <tr>
                <th className="py-3 px-4">Product Name</th>
                <th className="py-3 px-3 text-right">Current Stock</th>
                <th className="py-3 px-3">Sales Velocity</th>
                <th className="py-3 px-3 text-right">Days Remaining</th>
                <th className="py-3 px-3">Stockout Risk</th>
                <th className="py-3 px-3">Recommended Action</th>
                <th className="py-3 px-4 text-right">Tools</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {productMetrics.map((p) => {
                const days = p.daysRemaining;
                const isHighRisk = days !== null && days <= 7;

                let actionText = 'Maintain standard buffer stock.';
                if (days !== null) {
                  if (days <= 7) actionText = 'Review Reorder immediately.';
                  else if (days <= 21) actionText = 'Monitor stock runway weekly.';
                  else actionText = 'Healthy inventory level.';
                }

                return (
                  <tr
                    key={p.productId}
                    onClick={() => openProductDetail(p)}
                    className="hover:bg-slate-50/70 cursor-pointer transition-colors group"
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-600 font-bold text-xs shrink-0">
                          <Package className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <span className="font-bold text-slate-900 block group-hover:text-blue-600 transition-colors">
                            {p.productName}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">{p.productId}</span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-3 text-right font-bold text-slate-900">
                      {p.currentStock !== null ? `${p.currentStock} units` : '—'}
                    </td>

                    <td className="py-3 px-3 text-slate-700">
                      {getVelocityBadge(p.velocity)}
                    </td>

                    <td className="py-3 px-3 text-right font-bold">
                      <span className={isHighRisk ? 'text-rose-600 text-sm' : 'text-slate-800'}>
                        {days !== null ? `${days} days` : 'N/A'}
                      </span>
                    </td>

                    <td className="py-3 px-3">
                      {getRiskBadge(days, p.status)}
                    </td>

                    <td className="py-3 px-3 text-slate-700 font-medium">
                      {actionText}
                    </td>

                    <td className="py-3 px-4 text-right">
                      {p.currentStock !== null ? (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            openReorderCalculator(p);
                          }}
                          className="px-2.5 py-1 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded transition-colors inline-flex items-center gap-1 shadow-2xs"
                        >
                          <Calculator className="w-3 h-3 text-blue-600" />
                          <span>Reorder Calc</span>
                        </button>
                      ) : (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            openProductDetail(p);
                          }}
                          className="text-xs text-blue-600 hover:underline"
                        >
                          View SKU
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
